-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: paytime_manager_demo
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee_details`
--

DROP TABLE IF EXISTS `employee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_details` (
  `EMP_ID` int NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_email` varchar(255) NOT NULL,
  `EMP_DOB` date NOT NULL,
  `emp_bloodgroup` varchar(255) NOT NULL,
  `emp_gender` varchar(255) NOT NULL,
  `emp_maritalstatus` varchar(255) NOT NULL,
  `emp_national_id` varchar(255) NOT NULL,
  `emp_phoneno` varchar(255) NOT NULL,
  `emp_role` varchar(255) NOT NULL,
  `EMP_ACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `EMP_ISPAYROLL` tinyint(1) NOT NULL DEFAULT '0',
  `EMP_PAYROLLMANAGER` int DEFAULT NULL,
  `EMP_CREATED_AT` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `EMP_UPDATED_AT` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `emp_isadmin` bit(1) DEFAULT NULL,
  PRIMARY KEY (`EMP_ID`),
  UNIQUE KEY `EMP_EMAIL` (`emp_email`),
  UNIQUE KEY `EMP_NATIONAL_ID` (`emp_national_id`),
  KEY `EMP_PAYROLLMANAGER` (`EMP_PAYROLLMANAGER`),
  KEY `EMP_ROLE` (`emp_role`),
  CONSTRAINT `employee_details_ibfk_1` FOREIGN KEY (`EMP_PAYROLLMANAGER`) REFERENCES `employee_details` (`EMP_ID`),
  CONSTRAINT `employee_details_chk_1` CHECK (regexp_like(`emp_name`,_utf8mb4'^[A-Za-z ]+$')),
  CONSTRAINT `employee_details_chk_2` CHECK (regexp_like(`emp_national_id`,_utf8mb4'^[0-9]{12}$')),
  CONSTRAINT `employee_details_chk_3` CHECK (regexp_like(`emp_phoneno`,_utf8mb4'^[0-9]{10}$'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_details`
--

LOCK TABLES `employee_details` WRITE;
/*!40000 ALTER TABLE `employee_details` DISABLE KEYS */;
INSERT INTO `employee_details` VALUES (2374000,'Barath','barath2145@gmail.com','2002-03-17','O-','Male','Single','345678988456','7654321098','Programmer Analyst Trainee',1,0,NULL,'2025-01-31 05:20:49','2025-01-31 05:20:48','ICICI Bank','Barath','3456789012345678','ICICINBB','Bangalore','$2a$10$ErbzCxB9v4ovpMybiD1NnuWNbeKFmS1DoHJDCorlUvisNbP5f6vKq',_binary '\0'),(2374917,'Aarav Sharma','priyanshu.4302@gmail.com','1985-05-15','A+','Male','Single','123456789014','9876543210','Admin',1,0,NULL,'2025-01-02 17:26:06','2025-01-30 13:04:11','State Bank of India','Aarav Sharma','1234567890123456','SBININBB','Mumbai','$2a$10$BT5b2j3Kw49dRgW3Bw8wZueXqLMg/KbMkn5klvrmDoOwsEcSbRlp.',_binary '\0'),(2374918,'Ananya Singh','ananya.singh@example.com','1990-08-22','B+','Female','Married','234567890123','8765432109','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','HDFC Bank','Ananya Singh','2345678901234567','HDFCINBB','Delhi','$2a$10$qAwfHYcBRmtvNI2tcDg0i.KDNor9xKL6ty2HqCXKEReSV9A4rpR8C',_binary '\0'),(2374919,'Priyanshu','0987thegod@gmail.com','1982-11-30','O-','Male','Single','345678901234','7654321098','Sr. Developer',1,1,NULL,'2025-01-02 17:26:06','2025-01-30 15:37:16','ICICI Bank','Vihaan Patel','3456789012345678','ICICINBB','Bangalore','$2a$10$Gu6t4UiLsu8s0Yw/69AJ2OCQxrnR1CMNTaYJnwekhVUnQkvE5iMM.',_binary '\0'),(2374920,'Diya Nair','diya.nair@example.com','1975-02-14','AB+','Female','Married','456789012345','6543210987','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Axis Bank','Diya Nair','4567890123456789','UTIBINBB','Chennai','$2a$10$mUDooAJDC2cousAOhu8YtuC6jDorNUoGDkjh4vJee2rRDyG1nmr/e',_binary '\0'),(2374921,'Arjun Reddy','arjun.reddy@example.com','1995-07-19','A-','Male','Single','567890123456','5432109876','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Kotak Mahindra Bank','Arjun Reddy','5678901234567890','KKBKINBB','Hyderabad','$2a$10$u3YCh8qdElrvV9/1he9iwOfpdGMgg.4Eo0tyr9u.Mnc86imc8HsJ.',_binary '\0'),(2374922,'Ishita Mehta','ishita.mehta@example.com','1988-03-25','B-','Female','Married','678901234567','4321098765','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','IndusInd Bank','Ishita Mehta','6789012345678901','INDBINBB','Pune','$2a$10$HZUwHH/RAdAhHl.DmlD/AORK6T1EISC6hcOYDLCFW7GY0hjL339YG',_binary '\0'),(2374923,'Kabir Gupta','kabir.gupta@example.com','1992-12-05','O+','Male','Single','789012345678','3210987654','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Yes Bank','Kabir Gupta','7890123456789012','YESBINBB','Kolkata','$2a$10$CYeLuw6Eb2QNEUN0mFn3COi.T.ZtLF0h59a9TogwAfk7CmfHNzM9G',_binary '\0'),(2374924,'Meera Iyer','meera.iyer@example.com','1980-06-17','AB-','Female','Divorced','890123456789','2109876543','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Punjab National Bank','Meera Iyer','8901234567890123','PUNBINBB','Ahmedabad','$2a$10$3H1YNbp6m8sxK7RlaQNHrOeqX1G6kGNNqTDy28LnX54EfL.7zYMGa',_binary '\0'),(2374925,'Rohan Desai','rohan.desai@example.com','1983-09-23','A+','Male','Widowed','901234567890','1098765432','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Bank of Baroda','Rohan Desai','9012345678901234','BARBINBB','Surat','$2a$10$Bo/ppXTtFCEcGDQGqoPHfuYMArMCDC4vWc6rwKMUCEAQCM/Ql2Xk2',_binary '\0'),(2374926,'Saanvi Joshi','saanvi.joshi@example.com','1991-01-11','B+','Female','Single','012345678901','0987654321','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Canara Bank','Saanvi Joshi','0123456789012345','CNRBINBB','Jaipur','$2a$10$E9cjUrjCiQFm2xB0xQQK6.ilJjBsOrlhq33bd85RTksFLL30Ygf1q',_binary '\0'),(2374927,'Ayaan Kumar','ayaan.kumar@example.com','1987-04-28','O-','Male','Married','123456789012','9876543210','Sr. Developer',1,1,NULL,'2025-01-02 17:22:35','2025-01-23 15:50:11','State Bank of India','Ayaan Kumar','1234567890123456','SBININBB','Lucknow','$2a$10$9f2HpglDRGYxwJpcM5hpyux50pRHBjrhUDMkczUnk6JjED6iS3CFS',_binary '\0'),(2374928,'Nisha Verma','nisha.verma@example.com','1978-10-09','AB+','Female','Divorced','234567890124','8765432109','Programmer Analyst Trainee',1,1,NULL,'2025-01-02 17:26:06','2025-01-31 05:26:04','HDFC Bank','Nisha Verma','2345678901234567','HDFCINBB','Nagpur','$2a$10$isUsfQquNsQ6.6UOSxKzFOjZFm8sv6/v3Iquoy6c4OAi4oNWGyZ/2',_binary '\0'),(2374929,'Ravi Sharma','ravi.sharma@example.com','1993-05-21','A-','Male','Single','345678901235','7654321098','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','ICICI Bank','Ravi Sharma','3456789012345678','ICICINBB','Indore','$2a$10$opax5o1A.yyQWaw35/Fuu.10xq2t8cLBUJL/cg4d24N19uPjpvIl2',_binary '\0'),(2374930,'Pooja Singh','pooja.singh@example.com','1984-08-16','B-','Female','Married','456789013345','6543210987','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Axis Bank','Pooja Singh','4567890123456789','UTIBINBB','Bhopal','$2a$10$XlvA4GByweuvnjmWgNBQPuoGhHniohWlFWV1Iakm9AKa.hZdO7qTe',_binary '\0'),(2374931,'Vikram Rao','vikram.rao@example.com','1996-11-03','O+','Male','Single','567890123455','5432109876','Programmer Analyst Trainee',1,0,2374927,'2025-01-02 17:26:06','2025-01-29 04:02:46','Kotak Mahindra Bank','Vikram Rao','5678901234567890','KKBKINBB','Patna','$2a$10$eYiSE0ofIFtfIIKFxU0A5.P1X3Ll4AZxn8ZLmc0YLuJuou9PwcMae',_binary '\0'),(2374932,'Rajesh Kumar','rajesh.kumar@example.com','1980-01-01','A+','Male','Single','123456789456','9876543210','Sr. Developer',1,0,NULL,'2025-01-23 15:50:11','2025-01-23 16:04:41','State Bank of India','Rajesh Kumar','1234567890123456','SBININBB','Mumbai','$2a$10$uLt9v4C/DcsErhWzUYX/j.WO7vkVORgnfWNFy4bBavwwGLWXdHMNG',_binary ''),(2374933,'ajay','ajay@gmail.com','1985-02-02','B+','Female','Married','234567890456','8765432109','Sr. Developer',1,0,NULL,'2025-01-23 15:50:11','2025-01-30 15:40:28','HDFC Bank','Priya Sharma','2345678901234567','HDFCINBB','Delhi','$2a$10$ofgqoiUAM9vV1r6shaLPQu5.mLrH1yfB0JRrA/ED4XMzqk8vGXeZ.',_binary ''),(2374934,'Amit Verma','amit.verma@example.com','1990-03-03','O-','Male','Single','345678901456','7654321098','Sr. Developer',1,0,NULL,'2025-01-30 03:47:42','2025-01-30 03:47:42','ICICI Bank','Amit Verma','3456789012345678','ICICINBB','Bangalore','$2a$10$1hm8GvXp8KPVxGQ1mlaZWuE//nz3NZN4k2LYTeXoLhjO9Hu5UYfk6',_binary '\0'),(2374999,'Rishabhan','rishabhan@gmail.com','1990-03-01','O-','Male','Single','345678901410','8654300098','Sr. Developer',1,0,NULL,'2025-01-30 04:24:36','2025-01-30 04:24:36','ICICI Bank','Rishabhan','2456789012345679','ICICINBB','Bangalore','$2a$10$mb85EJYQDvkdivJ4GaQMn.m6/r2RsXVSf715r446gCdB31oExPSC.',_binary '\0');
/*!40000 ALTER TABLE `employee_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-06 12:21:39
