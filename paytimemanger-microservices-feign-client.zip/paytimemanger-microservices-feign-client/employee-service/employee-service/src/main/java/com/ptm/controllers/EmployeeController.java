package com.ptm.controllers;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeNameDTO;
import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.models.Employee;
import com.ptm.services.EmployeeService;
import com.ptm.services.RoleAssignService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
@Slf4j
public class EmployeeController {
    private final EmployeeService employeeService;

    private final RoleAssignService roleAssignService;

    @GetMapping("/salary-employees")
    public List<Employee> findByEmpRoleNot() {
        return employeeService.findByEmpRoleNot();
    }

    @GetMapping("/name/{empId}")
    public ResponseEntity<EmployeeNameDTO> getEmployeeName(@PathVariable int empId){
        return ResponseEntity.ok(employeeService.getEmployeeNameByEmpId(empId));
    }
    @PostMapping
    public ResponseEntity<CustomResponse> addEmployee(@Valid @RequestBody EmployeeDTO employeeDTO) {
        log.info("Adding new employee: {}", employeeDTO);
        CustomResponse response = employeeService.addEmployee(employeeDTO);
        log.info("Employee added successfully.");
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getAllEmployee() {
        log.info("Fetching all employees.");
        return ResponseEntity.ok(employeeService.getAll());
    }

    @GetMapping("/{empId}")
    public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable int empId) {
        log.info("Fetching employee with ID: {}", empId);
        return new ResponseEntity<>(employeeService.getEmployeeById(empId), HttpStatus.OK);
    }

    @PatchMapping("/promote/{id}")
    public ResponseEntity<CustomResponse> promoteToPayrollManager(@PathVariable int id) {
        try {
            log.info("Promoting employee with ID: {} to payroll manager.", id);
            roleAssignService.promoteToPayrollManager(id);
            CustomResponse response = new CustomResponse(
                    HttpStatus.OK.value(),
                    "Employee promoted to payroll manager successfully",
                    LocalDateTime.now()
            );
            log.info("Employee ID: {} promoted to payroll manager successfully.", id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error promoting employee with ID: {} to payroll manager.", id, e);
            CustomResponse response = new CustomResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Error promoting employee to payroll manager",
                    LocalDateTime.now()
            );
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/payroll-managers")
    public List<EmployeeRoleDTO> getAllPayrollManagers() {
        log.info("Fetching all payroll managers.");
        return roleAssignService.getAllPayrollManagers();
    }

    @PatchMapping("/demote/{id}")
    public ResponseEntity<CustomResponse> demoteFromPayrollManager(@PathVariable int id) {
        try {
            log.info("Demoting employee with ID: {} from payroll manager.", id);
            roleAssignService.demoteFromPayrollManager(id);
            CustomResponse response = new CustomResponse(
                    HttpStatus.OK.value(),
                    "Employee demoted from payroll manager successfully",
                    LocalDateTime.now()
            );
            log.info("Employee ID: {} demoted from payroll manager successfully.", id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error demoting employee with ID: {} from payroll manager.", id, e);
            CustomResponse response = new CustomResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Error demoting employee from payroll manager",
                    LocalDateTime.now()
            );
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PatchMapping("/assign-manager/{empId}/{payrollManagerId}")
    public ResponseEntity<CustomResponse> assignPayrollManager(@PathVariable int empId, @PathVariable int payrollManagerId) {
        try {
            log.info("Assigning payroll manager ID: {} to employee ID: {}.", payrollManagerId, empId);
            roleAssignService.assignPayrollManager(empId, payrollManagerId);
            CustomResponse response = new CustomResponse(
                    HttpStatus.OK.value(),
                    "Payroll manager assigned to employee successfully",
                    LocalDateTime.now()
            );
            log.info("Payroll manager ID: {} assigned to employee ID: {} successfully.", payrollManagerId, empId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error assigning payroll manager ID: {} to employee ID: {}.", payrollManagerId, empId, e);
            CustomResponse response = new CustomResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Error assigning payroll manager to employee",
                    LocalDateTime.now()
            );
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
