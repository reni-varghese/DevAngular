package com.ptm.services.impl;

import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.RoleAssignRepository;
import com.ptm.services.RoleAssignService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
@Slf4j
public class RoleAssignServiceImpl implements RoleAssignService {

    private final RoleAssignRepository roleAssignRepository;

    private EmployeeRoleDTO convertToDTO(Employee employee) {
        EmployeeRoleDTO dto = new EmployeeRoleDTO();
        dto.setEmpId(employee.getEmpId());
        dto.setEmpName(employee.getEmpName());
        dto.setEmpRole(employee.getEmpRole());
        dto.setEmpIsPayroll(employee.isEmpIsPayroll());
        dto.setEmpPayrollManager(employee.getEmpPayrollManager());
        return dto;
    }

    @Override
    public void promoteToPayrollManager(int empId) {
        log.info("Promoting employee with ID: {} to Payroll Manager.", empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        if (employee.isPresent()) {
            Employee e = employee.get();
            e.setEmpRole("Payroll Manager");
            e.setEmpIsPayroll(true);
            roleAssignRepository.save(e);
            log.info("Employee with ID: {} promoted to Payroll Manager successfully.", empId);
        } else {
            log.error("Employee not found with ID: {}", empId);
            throw new EmployeeNotFoundException("Employee not found with id " + empId);
        }
    }

    @Override
    public List<EmployeeRoleDTO> getAllPayrollManagers() {
        log.info("Fetching all Payroll Managers.");
        List<EmployeeRoleDTO> payrollManagers = roleAssignRepository.findAll().stream()
                .filter(Employee::isEmpIsPayroll)
                .map(this::convertToDTO)
                .toList();
        log.info("All Payroll Managers fetched successfully.");
        return payrollManagers;
    }

    @Override
    public void demoteFromPayrollManager(int empId) {
        log.info("Demoting employee with ID: {} from Payroll Manager.", empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        if (employee.isPresent()) {
            Employee e = employee.get();
            e.setEmpRole("Employee");
            e.setEmpIsPayroll(false);
            e.setEmpPayrollManager(null);
            roleAssignRepository.save(e);
            log.info("Employee with ID: {} demoted from Payroll Manager successfully.", empId);
        } else {
            log.error("Employee not found with ID: {}", empId);
            throw new EmployeeNotFoundException("Employee not found with id " + empId);
        }
    }

    @Override
    public void assignPayrollManager(int empId, int payrollManagerId) {
        log.info("Assigning Payroll Manager ID: {} to employee ID: {}.", payrollManagerId, empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        Optional<Employee> payrollManager = roleAssignRepository.findById(payrollManagerId);
        if (employee.isPresent() && payrollManager.isPresent()) {
            employee.get().setEmpPayrollManager(payrollManagerId);
            roleAssignRepository.save(employee.get());
            log.info("Payroll Manager ID: {} assigned to employee ID: {} successfully.", payrollManagerId, empId);
        } else {
            log.error("Employee or Payroll Manager not found. Employee ID: {}, Payroll Manager ID: {}", empId, payrollManagerId);
            throw new EmployeeNotFoundException("Employee or Payroll Manager not found");
        }
    }
}
