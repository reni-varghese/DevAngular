package com.ptm.services;

import com.ptm.dto.EmployeeRoleDTO;

import java.util.List;


public interface RoleAssignService {

    void promoteToPayrollManager(int empId);
    List<EmployeeRoleDTO> getAllPayrollManagers();
    void demoteFromPayrollManager(int empId);
    void assignPayrollManager(int empId, int payrollManagerId);
}
