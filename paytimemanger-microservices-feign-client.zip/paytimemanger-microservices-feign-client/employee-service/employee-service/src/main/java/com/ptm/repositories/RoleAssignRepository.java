package com.ptm.repositories;

import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.models.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoleAssignRepository extends JpaRepository<Employee, Integer> {
    List<EmployeeRoleDTO> findByEmpRole(String empRole);
}
