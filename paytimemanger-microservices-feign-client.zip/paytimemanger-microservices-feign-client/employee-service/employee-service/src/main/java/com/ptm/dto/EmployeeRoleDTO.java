package com.ptm.dto;



import lombok.Data;

@Data
public class EmployeeRoleDTO {
    private int empId;
    private String empName;
    private String empRole;
    private boolean empIsPayroll;
    private Integer empPayrollManager;
}
