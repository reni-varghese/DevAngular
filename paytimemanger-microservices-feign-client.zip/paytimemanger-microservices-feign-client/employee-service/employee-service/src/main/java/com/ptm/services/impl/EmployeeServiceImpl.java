package com.ptm.services.impl;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeNameDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.exceptions.EmployeeAlreadyExistsException;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.services.EmailService;
import com.ptm.services.EmployeeService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

//    private final PasswordEncoder passwordEncoder;
    private final EmployeeRepository employeeRepository;
    private final EmailService emailService;


    @Override
    public EmployeeNameDTO getEmployeeNameByEmpId(int empId){
        log.info("Fetching employee Name by ID: {}", empId);
        Employee employee = employeeRepository.findById(empId)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + empId + " not found"));
        return convertToEmployeeNameDTO(employee);

    }
    @Override
    public CustomResponse addEmployee(EmployeeDTO employeeDTO) {
        if (employeeRepository.existsById(employeeDTO.getEmpId())) {
            log.error("Employee with ID {} already exists", employeeDTO.getEmpId());
            throw new EmployeeAlreadyExistsException("Employee with ID " + employeeDTO.getEmpId() + " already exists");
        }
        employeeDTO.setPassword(userPassword(employeeDTO.getEmpId()));
        try {
            emailService.sendEmployeeDetailsEmail(employeeDTO);
        } catch (Exception ex) {
            log.error("Unable to send email to {}", employeeDTO.getEmpEmail(), ex);
            throw new EmployeeNotFoundException("Unable to send an email");
        }

        Employee employee = convertToEntity(employeeDTO);
        Employee savedEmployee = employeeRepository.save(employee);

        CustomResponse response = new CustomResponse();
        response.setTimestamp(LocalDateTime.now());
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Employee with ID " + savedEmployee.getEmpId() + " is added successfully");

        log.info("Employee with ID {} is added successfully", savedEmployee.getEmpId());

        return response;
    }

    @Override
    public EmployeeDTO getEmployeeById(int id) {
        log.info("Fetching employee by ID: {}", id);
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + id + " not found"));
        return convertToDTO(employee);
    }

    @Override
    public List<EmployeeDTO> getAll() {
        log.info("Fetching all employees");
        return employeeRepository.findAll().stream()
                .map(this::convertToDTO)
                .toList();
    }

    public String userPassword(int empId) {
        return "Pass" + empId;
    }

    private Employee convertToEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setEmpId(employeeDTO.getEmpId());
        employee.setEmpName(employeeDTO.getEmpName());
        employee.setEmpEmail(employeeDTO.getEmpEmail());
        employee.setEmpDob(employeeDTO.getEmpDob());
        employee.setEmpBloodGroup(employeeDTO.getEmpBloodGroup());
        employee.setEmpGender(employeeDTO.getEmpGender());
        employee.setEmpMaritalStatus(employeeDTO.getEmpMaritalStatus());
        employee.setEmpNationalId(employeeDTO.getEmpNationalId());
        employee.setEmpPhoneNo(employeeDTO.getEmpPhoneNo());
        employee.setEmpRole(employeeDTO.getEmpRole());
        employee.setEmpActive(employeeDTO.isEmpActive());
        employee.setEmpIsPayroll(employeeDTO.isEmpIsPayroll());
        employee.setEmpPayrollManager(employeeDTO.getEmpPayrollManager());
        employee.setBankName(employeeDTO.getBankName());
        employee.setAccountHolderName(employeeDTO.getAccountHolderName());
        employee.setAccountNumber(employeeDTO.getAccountNumber());
        employee.setIfscCode(employeeDTO.getIfscCode());
        employee.setBranch(employeeDTO.getBranch());
        employee.setEmpCreatedAt(Timestamp.valueOf(LocalDateTime.now()));
        employee.setEmpUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
        employee.setPassword(userPassword(employee.getEmpId()));
        employee.setEmpIsAdmin(employee.isEmpIsAdmin());
        return employee;
    }

    private EmployeeDTO convertToDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setEmpId(employee.getEmpId());
        employeeDTO.setEmpName(employee.getEmpName());
        employeeDTO.setEmpEmail(employee.getEmpEmail());
        employeeDTO.setEmpDob(employee.getEmpDob());
        employeeDTO.setEmpBloodGroup(employee.getEmpBloodGroup());
        employeeDTO.setEmpGender(employee.getEmpGender());
        employeeDTO.setEmpMaritalStatus(employee.getEmpMaritalStatus());
        employeeDTO.setEmpNationalId(employee.getEmpNationalId());
        employeeDTO.setEmpPhoneNo(employee.getEmpPhoneNo());
        employeeDTO.setEmpRole(employee.getEmpRole());
        employeeDTO.setEmpActive(employee.isEmpActive());
        employeeDTO.setEmpIsPayroll(employee.isEmpIsPayroll());
        employeeDTO.setEmpPayrollManager(employee.getEmpPayrollManager());
        employeeDTO.setBankName(employee.getBankName());
        employeeDTO.setAccountHolderName(employee.getAccountHolderName());
        employeeDTO.setAccountNumber(employee.getAccountNumber());
        employeeDTO.setIfscCode(employee.getIfscCode());
        employeeDTO.setBranch(employee.getBranch());
        return employeeDTO;
    }

    private EmployeeNameDTO convertToEmployeeNameDTO(Employee employee){
        EmployeeNameDTO employeeNameDTO = new EmployeeNameDTO();
        employeeNameDTO.setEmpName(employee.getEmpName());
        return  employeeNameDTO;
    }
    @Override
    public List<Employee> findByEmpRoleNot() {
        return employeeRepository.findByEmpRoleNot();
    }
}
