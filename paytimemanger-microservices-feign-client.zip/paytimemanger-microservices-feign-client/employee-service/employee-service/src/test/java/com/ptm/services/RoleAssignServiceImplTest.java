package com.ptm.services;

import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.RoleAssignRepository;
import com.ptm.services.impl.RoleAssignServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RoleAssignServiceImplTest {

    @Mock
    private RoleAssignRepository roleAssignRepository;

    @InjectMocks
    private RoleAssignServiceImpl roleAssignService;

    private Employee employee;
    private Employee payrollManager;
    private EmployeeRoleDTO employeeRoleDTO;

    @BeforeEach
    public void setUp() {
        employee = new Employee();
        employee.setEmpId(1);
        employee.setEmpName("John Doe");
        employee.setEmpRole("Employee");
        employee.setEmpIsPayroll(false);
        employee.setEmpPayrollManager(null);

        payrollManager = new Employee();
        payrollManager.setEmpId(2);
        payrollManager.setEmpName("Jane Doe");
        payrollManager.setEmpRole("Payroll Manager");
        payrollManager.setEmpIsPayroll(true);

        employeeRoleDTO = new EmployeeRoleDTO();
        employeeRoleDTO.setEmpId(1);
        employeeRoleDTO.setEmpName("John Doe");
        employeeRoleDTO.setEmpRole("Employee");
        employeeRoleDTO.setEmpIsPayroll(false);
        employeeRoleDTO.setEmpPayrollManager(null);
    }

    @Test
    public void testPromoteToPayrollManager_EmployeeNotFound() {
        when(roleAssignRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> roleAssignService.promoteToPayrollManager(1));
    }

    @Test
    public void testPromoteToPayrollManager_Success() {
        when(roleAssignRepository.findById(1)).thenReturn(Optional.of(employee));

        roleAssignService.promoteToPayrollManager(1);

        assertEquals("Payroll Manager", employee.getEmpRole());
        assertTrue(employee.isEmpIsPayroll());
        verify(roleAssignRepository, times(1)).save(employee);
    }

    @Test
    public void testGetAllPayrollManagers_Success() {
        employee.setEmpIsPayroll(true);
        when(roleAssignRepository.findAll()).thenReturn(List.of(employee));

        List<EmployeeRoleDTO> result = roleAssignService.getAllPayrollManagers();

        assertEquals(1, result.size());
        assertEquals(employee.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testDemoteFromPayrollManager_EmployeeNotFound() {
        when(roleAssignRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> roleAssignService.demoteFromPayrollManager(1));
    }

    @Test
    public void testDemoteFromPayrollManager_Success() {
        employee.setEmpRole("Payroll Manager");
        employee.setEmpIsPayroll(true);
        when(roleAssignRepository.findById(1)).thenReturn(Optional.of(employee));

        roleAssignService.demoteFromPayrollManager(1);

        assertEquals("Employee", employee.getEmpRole());
        assertFalse(employee.isEmpIsPayroll());
        assertNull(employee.getEmpPayrollManager());
        verify(roleAssignRepository, times(1)).save(employee);
    }

    @Test
    public void testAssignPayrollManager_EmployeeOrPayrollManagerNotFound() {
        when(roleAssignRepository.findById(1)).thenReturn(Optional.empty());
        when(roleAssignRepository.findById(2)).thenReturn(Optional.of(payrollManager));

        assertThrows(EmployeeNotFoundException.class, () -> roleAssignService.assignPayrollManager(1, 2));
    }

    @Test
    public void testAssignPayrollManager_Success() {
        when(roleAssignRepository.findById(1)).thenReturn(Optional.of(employee));
        when(roleAssignRepository.findById(2)).thenReturn(Optional.of(payrollManager));

        roleAssignService.assignPayrollManager(1, 2);

        assertEquals(2, employee.getEmpPayrollManager());
        verify(roleAssignRepository, times(1)).save(employee);
    }
}