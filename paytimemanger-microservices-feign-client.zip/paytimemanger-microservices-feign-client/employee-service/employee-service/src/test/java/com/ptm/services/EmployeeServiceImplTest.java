package com.ptm.services;

import com.ptm.dto.EmployeeDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.exceptions.EmployeeAlreadyExistsException;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.services.impl.EmployeeServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceImplTest {

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    private EmployeeDTO employeeDTO;
    private Employee employee;

    @BeforeEach
    void setUp() {
        employeeDTO = new EmployeeDTO();
        employeeDTO.setEmpId(1);
        employeeDTO.setEmpName("John Doe");
        employeeDTO.setEmpEmail("john.doe@example.com");
        // Set other fields for employeeDTO...

        employee = new Employee();
        employee.setEmpId(1);
        employee.setEmpName("John Doe");
        employee.setEmpEmail("john.doe@example.com");
        // Set other fields for employee...
    }

    @Test
    void addEmployee_success() {
        when(employeeRepository.existsById(employeeDTO.getEmpId())).thenReturn(false);
        when(passwordEncoder.encode(any(String.class))).thenReturn("encodedPassword");
        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);

        CustomResponse response = employeeService.addEmployee(employeeDTO);

        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCode());
        assertEquals("Employee with ID 1 is added successfully", response.getMessage());
        verify(emailService, times(1)).sendEmployeeDetailsEmail(employeeDTO);
        verify(employeeRepository, times(1)).save(any(Employee.class));
    }

    @Test
    void addEmployee_alreadyExists() {
        when(employeeRepository.existsById(employeeDTO.getEmpId())).thenReturn(true);

        assertThrows(EmployeeAlreadyExistsException.class, () -> employeeService.addEmployee(employeeDTO));
        verify(emailService, times(0)).sendEmployeeDetailsEmail(employeeDTO);
        verify(employeeRepository, times(0)).save(any(Employee.class));
    }

    @Test
    void addEmployee_emailSendingException() {
        when(employeeRepository.existsById(employeeDTO.getEmpId())).thenReturn(false);
        doThrow(new RuntimeException("Email sending failed")).when(emailService).sendEmployeeDetailsEmail(employeeDTO);

        assertThrows(EmployeeNotFoundException.class, () -> employeeService.addEmployee(employeeDTO));
        verify(employeeRepository, times(0)).save(any(Employee.class));
    }

    @Test
    void getEmployeeById_success() {
        when(employeeRepository.findById(employee.getEmpId())).thenReturn(Optional.of(employee));

        EmployeeDTO fetchedEmployee = employeeService.getEmployeeById(employee.getEmpId());

        assertNotNull(fetchedEmployee);
        assertEquals(employee.getEmpId(), fetchedEmployee.getEmpId());
        verify(employeeRepository, times(1)).findById(employee.getEmpId());
    }

    @Test
    void getEmployeeById_notFound() {
        when(employeeRepository.findById(employee.getEmpId())).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> employeeService.getEmployeeById(employee.getEmpId()));
        verify(employeeRepository, times(1)).findById(employee.getEmpId());
    }

    @Test
    void getAll_success() {
        when(employeeRepository.findAll()).thenReturn(List.of(employee));

        List<EmployeeDTO> employees = employeeService.getAll();

        assertNotNull(employees);
        assertFalse(employees.isEmpty());
        assertEquals(1, employees.size());
        assertEquals(employee.getEmpId(), employees.get(0).getEmpId());
        verify(employeeRepository, times(1)).findAll();
    }
}
