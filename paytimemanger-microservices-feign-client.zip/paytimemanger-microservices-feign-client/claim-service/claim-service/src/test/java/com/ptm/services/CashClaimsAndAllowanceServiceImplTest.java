package com.ptm.services;

import com.ptm.dto.CashClaimsAndAllowanceDTO;
import com.ptm.exceptions.ClaimAttachmentNotFound;
import com.ptm.exceptions.ClaimIdAlreadyExist;
import com.ptm.exceptions.ClaimIdNotFoundException;
import com.ptm.models.CashClaimsAndAllowance;
import com.ptm.repositories.CashClaimsAndAllowanceRepository;
import com.ptm.services.impl.CashClaimsAndAllowanceServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CashClaimsAndAllowanceServiceImplTest {

    @Mock
    private CashClaimsAndAllowanceRepository repository;

    @Mock
    private MultipartFile file;

    @InjectMocks
    private CashClaimsAndAllowanceServiceImpl service;

    private CashClaimsAndAllowance claim;
    private CashClaimsAndAllowanceDTO claimDTO;

    @BeforeEach
    public void setUp() {
        claim = new CashClaimsAndAllowance();
        claim.setClaim_id(1);
        claim.setEmpId(1);
        claim.setDateOfClaim(LocalDate.now());
        claim.setDescription("Description");
        claim.setAmount(1000.0);
        claim.setRemark("Remark");
        claim.setAllowanceType("AllowanceType");

        claimDTO = new CashClaimsAndAllowanceDTO();
        claimDTO.setClaimId(1);
        claimDTO.setEmpId(1);
        claimDTO.setDateOfClaim(LocalDate.now());
        claimDTO.setDescription("Description");
        claimDTO.setAmount(1000.0);
        claimDTO.setRemark("Remark");
        claimDTO.setAllowanceType("AllowanceType");
    }

    @Test
    public void testGetAllClaims() {
        when(repository.findAll()).thenReturn(List.of(claim));

        List<CashClaimsAndAllowanceDTO> result = service.getAllClaims();

        assertEquals(1, result.size());
        assertEquals(claim.getClaim_id(), result.get(0).getClaimId());
    }

    @Test
    public void testGetClaimById_ClaimNotFound() {
        when(repository.findById(1)).thenReturn(Optional.empty());

        assertThrows(ClaimIdNotFoundException.class, () -> service.getClaimById(1));
    }

    @Test
    public void testGetClaimById_Success() {
        when(repository.findById(1)).thenReturn(Optional.of(claim));

        CashClaimsAndAllowanceDTO result = service.getClaimById(1);

        assertNotNull(result);
        assertEquals(claim.getClaim_id(), result.getClaimId());
    }

    @Test
    public void testSaveClaim_ClaimIdAlreadyExists() {
        when(repository.existsById(1)).thenReturn(true);

        assertThrows(ClaimIdAlreadyExist.class, () -> service.saveClaim(claim, file));
    }

    @Test
    public void testSaveClaim_Success() throws IOException {
        when(repository.existsById(1)).thenReturn(false);
        when(file.isEmpty()).thenReturn(false);
        when(file.getBytes()).thenReturn(new byte[]{1, 2, 3});
        when(repository.save(any(CashClaimsAndAllowance.class))).thenReturn(claim);

        CashClaimsAndAllowance result = service.saveClaim(claim, file);

        assertNotNull(result);
        assertEquals(claim.getClaim_id(), result.getClaim_id());
        verify(repository, times(1)).save(claim);
    }

    @Test
    public void testGetAttachmentByClaimId_ClaimNotFound() {
        when(repository.findById(1)).thenReturn(Optional.empty());

        assertThrows(ClaimAttachmentNotFound.class, () -> service.getAttachmentByClaimId(1));
    }

    @Test
    public void testGetAttachmentByClaimId_Success() {
        claim.setAttachment(new byte[]{1, 2, 3});
        when(repository.findById(1)).thenReturn(Optional.of(claim));

        byte[] result = service.getAttachmentByClaimId(1);

        assertNotNull(result);
        assertArrayEquals(claim.getAttachment(), result);
    }

    @Test
    public void testUpdateRemark_ClaimNotFound() {
        when(repository.findById(1)).thenReturn(Optional.empty());

        assertThrows(ClaimIdNotFoundException.class, () -> service.updateRemark(1, "New Remark"));
    }

    @Test
    public void testUpdateRemark_Success() {
        when(repository.findById(1)).thenReturn(Optional.of(claim));

        String result = service.updateRemark(1, "New Remark");

        assertEquals("Remark Updated Successfully", result);
        verify(repository, times(1)).save(claim);
    }

    @Test
    public void testFindCashClaimForEmployeeBetweenDateRange() {
        List<Object[]> results = new ArrayList<>();
        results.add(new Object[]{claim, "John Doe"});
        when(repository.findAllByEmpIdAndDateOfClaimBetween(1, LocalDate.now().minusDays(1), LocalDate.now())).thenReturn(results);

        List<CashClaimsAndAllowanceDTO> result = service.findCashClaimForEmployeeBetweenDateRange(1, LocalDate.now().minusDays(1), LocalDate.now());

        assertEquals(1, result.size());
        assertEquals(claim.getClaim_id(), result.get(0).getClaimId());
        assertEquals("John Doe", result.get(0).getEmpName());
    }
}