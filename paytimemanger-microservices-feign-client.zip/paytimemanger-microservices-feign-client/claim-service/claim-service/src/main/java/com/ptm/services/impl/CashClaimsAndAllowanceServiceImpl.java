package com.ptm.services.impl;

import com.ptm.dto.CashClaimsAndAllowanceDTO;
import com.ptm.dto.EmployeeNameDTO;
import com.ptm.exceptions.ClaimAttachmentNotFound;
import com.ptm.exceptions.ClaimIdAlreadyExist;
import com.ptm.exceptions.ClaimIdNotFoundException;
import com.ptm.models.CashClaimsAndAllowance;
import com.ptm.repositories.CashClaimsAndAllowanceRepository;
import com.ptm.services.ICashClaimsAndAllowanceService;
import com.ptm.client.EmployeeClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
@Service
@Slf4j

public class CashClaimsAndAllowanceServiceImpl implements ICashClaimsAndAllowanceService {
    private final CashClaimsAndAllowanceRepository repository;

    private final EmployeeClient employeeClient;

    @Autowired
    public CashClaimsAndAllowanceServiceImpl(CashClaimsAndAllowanceRepository repository, EmployeeClient employeeClient) {
        this.repository = repository;
        this.employeeClient = employeeClient;
    }

    @Override
    public List<CashClaimsAndAllowanceDTO> getAllClaims() {
        log.info("Fetching all claims.");
        List<CashClaimsAndAllowance> claims = repository.findAll();
        List<CashClaimsAndAllowanceDTO> dtos = new ArrayList<>();
        for (CashClaimsAndAllowance claim : claims) {
            CashClaimsAndAllowanceDTO dto = new CashClaimsAndAllowanceDTO();
            dto.setClaimId(claim.getClaim_id());
            dto.setEmpId(claim.getEmpId());
            dto.setDateOfClaim(claim.getDateOfClaim());
            dto.setDescription(claim.getDescription());
            dto.setAttachment(claim.getAttachment());
            dto.setAmount(claim.getAmount());
            dto.setRemark(claim.getRemark());
            dto.setDateOfAction(claim.getDateOfAction());
            dto.setAllowanceType(claim.getAllowanceType());

            // Fetch employee name from EmployeeService
            EmployeeNameDTO employeeNameDTO = employeeClient.getEmployeeName(claim.getEmpId()).getBody();
            dto.setEmpName(employeeNameDTO != null ? employeeNameDTO.getEmpName() : null);

            dtos.add(dto);
        }
        log.info("All claims fetched successfully.");
        return dtos;
    }

    @Override
    public CashClaimsAndAllowanceDTO getClaimById(int id) {
        log.info("Fetching claim by ID: {}", id);
        CashClaimsAndAllowance claims = repository.findById(id)
                .orElseThrow(() -> new ClaimIdNotFoundException("Claim with Id " + id + " not found"));
        CashClaimsAndAllowanceDTO dto = new CashClaimsAndAllowanceDTO();
        dto.setClaimId(claims.getClaim_id());
        dto.setEmpId(claims.getEmpId());
        dto.setDateOfClaim(claims.getDateOfClaim());
        dto.setDescription(claims.getDescription());
        dto.setAttachment(claims.getAttachment());
        dto.setAmount(claims.getAmount());
        dto.setRemark(claims.getRemark());
        dto.setDateOfAction(claims.getDateOfAction());
        dto.setAllowanceType(claims.getAllowanceType());

        // Fetch employee name from EmployeeService
        EmployeeNameDTO employeeNameDTO = employeeClient.getEmployeeName(claims.getEmpId()).getBody();
        dto.setEmpName(employeeNameDTO != null ? employeeNameDTO.getEmpName() : null);

        log.info("Claim ID: {} fetched successfully.", id);
        return dto;
    }

    @Override
    public CashClaimsAndAllowance saveClaim(CashClaimsAndAllowance claim, MultipartFile file) throws IOException {
        log.info("Saving claim ID: {}", claim.getClaim_id());
        if (repository.existsById(claim.getClaim_id())) {
            log.error("Claim ID: {} already exists.", claim.getClaim_id());
            throw new ClaimIdAlreadyExist("Claim ID " + claim.getClaim_id() + " already exists.");
        }
        if (file != null && !file.isEmpty()) {
            claim.setAttachment(file.getBytes());
        }
        CashClaimsAndAllowance savedClaim = repository.save(claim);
        log.info("Claim ID: {} saved successfully.", claim.getClaim_id());
        return savedClaim;
    }

    @Override
    public byte[] getAttachmentByClaimId(int id) {
        log.info("Fetching attachment for claim ID: {}", id);
        CashClaimsAndAllowance claim = repository.findById(id).orElse(null);
        if (claim == null || claim.getAttachment() == null) {
            log.error("Attachment not found for claim ID: {}", id);
            throw new ClaimAttachmentNotFound("Attachment not found for Claim ID " + id);
        }
        log.info("Attachment for claim ID: {} fetched successfully.", id);
        return claim.getAttachment();
    }

    @Override
    public String updateRemark(int id, String remark) {
        log.info("Updating remark for claim ID: {}", id);
        CashClaimsAndAllowance claim = repository.findById(id).orElse(null);
        if (claim != null) {
            claim.setRemark(remark);
            repository.save(claim);
            log.info("Remark for claim ID: {} updated successfully.", id);
        } else {
            log.error("Claim ID: {} not found.", id);
            throw new ClaimIdNotFoundException("Claim with id " + id + " does not exist");
        }
        return "Remark Updated Successfully";
    }

    @Override
    public List<CashClaimsAndAllowanceDTO> findCashClaimForEmployeeBetweenDateRange(int empId, LocalDate startDate, LocalDate endDate) {
        log.info("Fetching cash claims for employee ID: {} between {} and {}", empId, startDate, endDate);
        List<CashClaimsAndAllowance> claims = repository.findByEmpIdAndDateOfClaimBetween(empId, startDate, endDate);
        List<CashClaimsAndAllowanceDTO> dtos = new ArrayList<>();
        for (CashClaimsAndAllowance claim : claims) {
            CashClaimsAndAllowanceDTO dto = new CashClaimsAndAllowanceDTO();
            dto.setClaimId(claim.getClaim_id());
            dto.setEmpId(claim.getEmpId());
            dto.setDateOfClaim(claim.getDateOfClaim());
            dto.setDescription(claim.getDescription());
            dto.setAttachment(claim.getAttachment());
            dto.setAmount(claim.getAmount());
            dto.setRemark(claim.getRemark());
            dto.setDateOfAction(claim.getDateOfAction());
            dto.setAllowanceType(claim.getAllowanceType());

            // Fetch employee name from EmployeeService
            EmployeeNameDTO employeeNameDTO = employeeClient.getEmployeeName(claim.getEmpId()).getBody();
            dto.setEmpName(employeeNameDTO != null ? employeeNameDTO.getEmpName() : null);

            dtos.add(dto);
        }
        log.info("Cash claims for employee ID: {} between {} and {} fetched successfully.", empId, startDate, endDate);
        return dtos;
    }
    @Override
    public List<CashClaimsAndAllowance> findByEmpId(int empId) {
        return repository.findByEmpId(empId);
    }
}