package com.ptm.controllers;

import com.ptm.dto.CashClaimsAndAllowanceDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.models.CashClaimsAndAllowance;
import com.ptm.services.ICashClaimsAndAllowanceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/claims")
@RequiredArgsConstructor
@Slf4j
public class CashClaimsAndAllowanceController {

    private final ICashClaimsAndAllowanceService iCashClaimsAndAllowanceService;

    @GetMapping("/salary-claims")
    public List<CashClaimsAndAllowance> findByEmpId(@RequestParam int empId) {
        return iCashClaimsAndAllowanceService.findByEmpId(empId);
    }

    @GetMapping
//    @PreAuthorize("hasRole('PAYROLL_MANAGER')")
    public List<CashClaimsAndAllowanceDTO> getAllClaims() {
        log.info("Fetching all claims.");
        return iCashClaimsAndAllowanceService.getAllClaims();
    }

    @GetMapping("/{id}")
    public CashClaimsAndAllowanceDTO getClaimById(@PathVariable int id) {
        log.info("Fetching claim with ID: {}", id);
        return iCashClaimsAndAllowanceService.getClaimById(id);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

//    @PreAuthorize("hasRole('PAYROLL_MANAGER') or hasRole('USER')")
    public ResponseEntity<CustomResponse> saveClaim(
            @RequestPart("claim") CashClaimsAndAllowance claim,
            @RequestPart(value = "file", required = false) MultipartFile file) throws IOException {
        log.info("Saving a new claim: {}", claim);
        iCashClaimsAndAllowanceService.saveClaim(claim, file);
        CustomResponse response = new CustomResponse(
                HttpStatus.CREATED.value(),
                "Claim saved successfully",
                LocalDateTime.now()
        );
        log.info("Claim saved successfully.");
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/attachment/{id}")
//    @PreAuthorize("hasRole('PAYROLL_MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<byte[]> getAttachment(@PathVariable int id) {
        log.info("Fetching attachment for claim ID: {}", id);
        byte[] attachment = iCashClaimsAndAllowanceService.getAttachmentByClaimId(id);
        if (attachment == null) {
            log.warn("Attachment not found for claim ID: {}", id);
            return ResponseEntity.notFound().build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDisposition(ContentDisposition.attachment().build());
        log.info("Attachment fetched successfully for claim ID: {}", id);
        return ResponseEntity.ok()
                .headers(headers)
                .body(attachment);
    }

    @PatchMapping("/remark/{id}")
//    @PreAuthorize("hasRole('PAYROLL_MANAGER')")
    public ResponseEntity<CustomResponse> updateRemark(@PathVariable int id, @RequestBody CashClaimsAndAllowance claim) {
        log.info("Updating remark for claim ID: {}", id);
        iCashClaimsAndAllowanceService.updateRemark(id, claim.getRemark());
        CustomResponse response = new CustomResponse(
                HttpStatus.OK.value(),
                "Remark updated successfully",
                LocalDateTime.now()
        );
        log.info("Remark updated successfully for claim ID: {}", id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/employee/{empId}/date-range")
//    @PreAuthorize("hasRole('ADMIN')")
    public List<CashClaimsAndAllowanceDTO> findCashClaimForEmployeeBetweenDateRange(
            @PathVariable int empId,
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        log.info("Fetching cash claims for employee ID: {} between {} and {}", empId, startDate, endDate);
        List<CashClaimsAndAllowanceDTO> cashClaims = iCashClaimsAndAllowanceService.findCashClaimForEmployeeBetweenDateRange(empId, startDate, endDate);
        log.info("Cash claims found: {}", cashClaims);
        return cashClaims;
    }
}
