    package com.ptm.services.impl;

    import com.ptm.client.EmpClient;

    import com.ptm.dto.requests.EmployeeQueryDTO;
    import com.ptm.dto.responses.EmployeeNameDTO;
    import com.ptm.exceptions.EmployeeNotFoundException;
    import com.ptm.exceptions.QueryNotFoundException;
    import com.ptm.models.EmployeeQuery;
    import com.ptm.repositories.EmployeeQueryRepository;
    import com.ptm.services.EmployeeQueryService;

    import lombok.extern.slf4j.Slf4j;

    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Service;
    import org.springframework.http.ResponseEntity;

    import java.util.Date;
    import java.util.List;
    import java.util.stream.Collectors;


    @Service
    @Slf4j
    public class EmployeeQueryServiceImpl implements EmployeeQueryService {

        private final EmployeeQueryRepository employeeQueryRepository;

        private final EmpClient employeeClient;
        @Autowired
        public EmployeeQueryServiceImpl(EmployeeQueryRepository employeeQueryRepository, EmpClient employeeClient) {
            this.employeeQueryRepository = employeeQueryRepository;
            this.employeeClient = employeeClient;
        }

        @Override
        public void submitQuery(EmployeeQueryDTO employeeQueryDTO) {
            log.info("Submitting query for employee ID: {}", employeeQueryDTO.getEmpId());
            EmployeeQuery query = new EmployeeQuery();
            query.setEmpId(employeeQueryDTO.getEmpId());
            query.setCategory(employeeQueryDTO.getCategory());
            query.setDescription(employeeQueryDTO.getDescription());
            query.setStatus("In Progress");
            query.setFeedback(employeeQueryDTO.getFeedback());
            query.setDateOfCreated(new Date());
            employeeQueryRepository.save(query);
            log.info("Query for employee ID: {} submitted successfully.", employeeQueryDTO.getEmpId());
        }

        @Override
        public List<EmployeeQueryDTO> retrieveQueries() {
            log.info("Retrieving all employee queries.");
            List<EmployeeQuery> queries = employeeQueryRepository.findAll();
            List<EmployeeQueryDTO> queryDTOs = queries.stream().map(query -> {
                ResponseEntity<EmployeeNameDTO> response = employeeClient.getEmployeeName(query.getEmpId());
                String empName = response.getBody().getEmpName();

                EmployeeQueryDTO dto = new EmployeeQueryDTO();
                dto.setQueryId(query.getQueryId());
                dto.setEmpId(query.getEmpId());
                dto.setEmpName(empName);
                dto.setCategory(query.getCategory());
                dto.setDescription(query.getDescription());
                dto.setStatus(query.getStatus());
                dto.setFeedback(query.getFeedback());
                return dto;
            }).collect(Collectors.toList());
            log.info("Employee queries retrieved: {}", queries);
            return queryDTOs;
        }

        @Override
        public EmployeeQueryDTO getById(int queryId) {
            log.info("Fetching query by ID: {}", queryId);
            EmployeeQuery result = employeeQueryRepository.findById(queryId)
                    .orElseThrow(() -> new QueryNotFoundException("Query with ID " + queryId + " does not exist"));;
            if (result == null) {
                throw new QueryNotFoundException("Query with ID " + queryId + " does not exist");
            }

            ResponseEntity<EmployeeNameDTO> response = employeeClient.getEmployeeName(result.getEmpId());
            String empName = response.getBody().getEmpName();

            EmployeeQueryDTO dto = new EmployeeQueryDTO();
            dto.setQueryId(result.getQueryId());
            dto.setEmpName(empName);
            dto.setEmpId(result.getEmpId());
            dto.setCategory(result.getCategory());
            dto.setDescription(result.getDescription());
            dto.setStatus(result.getStatus());
            dto.setFeedback(result.getFeedback());

            log.info("Query ID: {} fetched successfully.", queryId);
            return dto;
        }

        @Override
        public void updateQuery(int queryId, EmployeeQueryDTO employeeQueryDTO) {
            log.info("Updating query ID: {}", queryId);
            EmployeeQuery existingQuery = employeeQueryRepository.findById(queryId)
                    .orElseThrow(() -> new QueryNotFoundException("Query with ID " + queryId + " does not exist"));

            if (employeeQueryDTO.getCategory() != null) {
                existingQuery.setCategory(employeeQueryDTO.getCategory());
            }
            if (employeeQueryDTO.getDescription() != null) {
                existingQuery.setDescription(employeeQueryDTO.getDescription());
            }

            existingQuery.setStatus("In Progress");
            existingQuery.setFeedback(employeeQueryDTO.getFeedback());
            employeeQueryRepository.save(existingQuery);
            log.info("Query ID: {} updated successfully.", queryId);
        }
    }