package com.ptm.services;

import com.ptm.dto.requests.EmployeeQueryDTO;
import com.ptm.models.EmployeeQuery;

import java.util.List;

public interface EmployeeQueryService {

    void submitQuery(EmployeeQueryDTO employeeQueryDTO);
    List<EmployeeQueryDTO> retrieveQueries();
    void updateQuery(int queryId, EmployeeQueryDTO employeeQueryDTO);
    EmployeeQueryDTO getById(int queryId);
}
