package com.ptm.dto.requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeQueryDTO {
    private int queryId;
    private int empId;
    private String category;
    private String description;
    private String status;
    private String feedback;
    private String empName;

}
