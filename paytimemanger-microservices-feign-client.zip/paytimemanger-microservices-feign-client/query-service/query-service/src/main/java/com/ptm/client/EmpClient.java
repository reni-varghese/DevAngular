package com.ptm.client;


import com.ptm.dto.responses.EmployeeNameDTO;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "employee-service")
public interface EmpClient {

    @GetMapping("/api/employees/name/{empId}")
    @CircuitBreaker(name = "employeeService", fallbackMethod = "fallbackGetEmployeeName")
    ResponseEntity<EmployeeNameDTO> getEmployeeName(@PathVariable int empId);

    default ResponseEntity<EmployeeNameDTO> fallbackGetEmployeeName(int empId, Throwable throwable) {
        EmployeeNameDTO defaultEmployee = new EmployeeNameDTO();
        defaultEmployee.setEmpName("Unknown");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(defaultEmployee);
    }

}
