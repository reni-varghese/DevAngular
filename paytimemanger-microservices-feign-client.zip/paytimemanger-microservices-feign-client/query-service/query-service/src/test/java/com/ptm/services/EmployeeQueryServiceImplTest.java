package com.ptm.services;

import com.ptm.dto.requests.EmployeeQueryDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.QueryNotFoundException;
import com.ptm.models.EmployeeQuery;
import com.ptm.repositories.EmployeeQueryRepository;
import com.ptm.services.impl.EmployeeQueryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeQueryServiceImplTest {
    @Mock
    private EmployeeQueryRepository employeeQueryRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeQueryServiceImpl employeeQueryService;

    private EmployeeQueryDTO employeeQueryDTO;
    private EmployeeQuery employeeQuery;
    private Employee employee;

    @BeforeEach
    public void setUp() {
        employeeQueryDTO = new EmployeeQueryDTO();
        employeeQueryDTO.setEmpId(1);
        employeeQueryDTO.setCategory("Category");
        employeeQueryDTO.setDescription("Description");
        employeeQueryDTO.setFeedback("Feedback");

        employeeQuery = new EmployeeQuery();
        employeeQuery.setEmpId(1);
        employeeQuery.setCategory("Category");
        employeeQuery.setDescription("Description");
        employeeQuery.setStatus("In Progress");
        employeeQuery.setFeedback("Feedback");
        employeeQuery.setDateOfCreated(new Date());

        employee = new Employee();
        employee.setEmpId(1);
        employee.setEmpName("John Doe");
    }

    @Test
    public void testSubmitQuery_EmployeeNotFound() {
        when(employeeRepository.existsById(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> employeeQueryService.submitQuery(employeeQueryDTO));
    }

    @Test
    public void testSubmitQuery_Success() {
        when(employeeRepository.existsById(1)).thenReturn(true);
        when(employeeQueryRepository.save(any(EmployeeQuery.class))).thenReturn(employeeQuery);

        employeeQueryService.submitQuery(employeeQueryDTO);

        verify(employeeQueryRepository, times(1)).save(any(EmployeeQuery.class));
    }

    @Test
    public void testRetrieveQueries() {
        when(employeeQueryRepository.findAll()).thenReturn(List.of(employeeQuery));
        when(employeeRepository.findByEmpId(1)).thenReturn(Optional.of(employee));

        List<EmployeeQueryDTO> result = employeeQueryService.retrieveQueries();

        assertEquals(1, result.size());
        assertEquals(employeeQuery.getEmpId(), result.get(0).getEmpId());
        assertEquals(employee.getEmpName(), result.get(0).getEmpName());
        assertEquals(employeeQuery.getStatus(), result.get(0).getStatus());
        assertEquals(employeeQuery.getFeedback(), result.get(0).getFeedback());
    }

    @Test
    public void testGetById_EmployeeNotFound() {
        when(employeeQueryRepository.findById(1)).thenReturn(employeeQuery);
        when(employeeRepository.findByEmpId(1)).thenReturn(Optional.empty());

        assertThrows(EmployeeNotFoundException.class, () -> employeeQueryService.getById(1));
    }

    @Test
    public void testGetById_Success() {
        when(employeeQueryRepository.findById(1)).thenReturn(Optional.ofNullable(employeeQuery));
        when(employeeRepository.findByEmpId(1)).thenReturn(Optional.of(employee));

        EmployeeQueryDTO result = employeeQueryService.getById(1);

        assertNotNull(result);
        assertEquals(employeeQuery.getEmpId(), result.getEmpId());
        assertEquals(employee.getEmpName(), result.getEmpName());
        assertEquals(employeeQuery.getStatus(), result.getStatus());
        assertEquals(employeeQuery.getFeedback(), result.getFeedback());
    }

    @Test
    public void testUpdateQuery_QueryNotFound() {
        when(employeeQueryRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(QueryNotFoundException.class, () -> employeeQueryService.updateQuery(1, employeeQueryDTO));
    }

    @Test
    public void testUpdateQuery_Success() {
        when(employeeQueryRepository.findById(1)).thenReturn(Optional.of(employeeQuery));
        when(employeeQueryRepository.save(any(EmployeeQuery.class))).thenReturn(employeeQuery);

        employeeQueryService.updateQuery(1, employeeQueryDTO);

        verify(employeeQueryRepository, times(1)).save(any(EmployeeQuery.class));
    }
}
