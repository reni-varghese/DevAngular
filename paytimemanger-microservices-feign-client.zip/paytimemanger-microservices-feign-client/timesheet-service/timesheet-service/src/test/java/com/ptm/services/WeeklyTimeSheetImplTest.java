package com.ptm.services;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.ResourceNotFoundException;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;
import com.ptm.repositories.TimeSheetRepository;
import com.ptm.repositories.WeeklyTimeSheetRepository;
import com.ptm.services.impl.WeeklyTimeSheetImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Time;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WeeklyTimeSheetImplTest {

    @Mock
    private TimeSheetService timeSheetService;

    @Mock
    private WeeklyTimeSheetRepository weeklyTimeSheetRepository;

    @Mock
    private TimeSheetRepository timeSheetRepository;

    @InjectMocks
    private WeeklyTimeSheetImpl weeklyTimeSheetService;

    private TimesheetDto timesheetDto;
    private TimeSheet timeSheet;
    private WeeklyTimeSheet weeklyTimeSheet;

    @BeforeEach
    public void setUp() {
        timesheetDto = new TimesheetDto();
        timesheetDto.setEmpId(1);
        timesheetDto.setDate(LocalDate.now());
        timesheetDto.setClockIn(Time.valueOf("09:00:00"));
        timesheetDto.setClockOut(Time.valueOf("17:00:00"));
        timesheetDto.setTopUpHours(2.0);

        timeSheet = new TimeSheet();
        timeSheet.setEmpId(1);
        timeSheet.setDate(LocalDate.now());
        timeSheet.setClock_In(Time.valueOf("09:00:00"));
        timeSheet.setClock_Out(Time.valueOf("17:00:00"));
        timeSheet.setTopup_Hours(2.0);
        timeSheet.setTotal_Hours(8.0); // Ensure this is set

        weeklyTimeSheet = new WeeklyTimeSheet();
        weeklyTimeSheet.setEmpId(1);
        weeklyTimeSheet.setWeekStart(LocalDate.now().with(DayOfWeek.MONDAY));
        weeklyTimeSheet.setWeekEnd(LocalDate.now().with(DayOfWeek.SUNDAY));
        weeklyTimeSheet.setTotalHours(40);
        weeklyTimeSheet.setOvertimeHours(5);
        weeklyTimeSheet.setStatus("Pending");
    }
    @Test
    public void testGetAll() {
        when(weeklyTimeSheetRepository.findAll()).thenReturn(List.of(weeklyTimeSheet));

        List<WeeklyTimeSheet> result = weeklyTimeSheetService.getAll();

        assertEquals(1, result.size());
        assertEquals(weeklyTimeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testGetTimeSheetsFromMondayToCurrent_EmployeeNotFound() {
        when(timeSheetService.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> weeklyTimeSheetService.getTimeSheetsFromMondayToCurrent(1, LocalDate.now()));
    }

    @Test
    public void testGetTimeSheetsFromMondayToCurrent() {
        when(timeSheetService.existsByEmpId(1)).thenReturn(true);
        when(weeklyTimeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetService.getByEmpIdAndDate(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(List.of(timesheetDto));

        List<TimeSheet> result = weeklyTimeSheetService.getTimeSheetsFromMondayToCurrent(1, LocalDate.now());

        assertEquals(1, result.size());
        assertEquals(timeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testGetPendingWeeklyTimesheets_InvalidStatus() {
        assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.getPendingWeeklyTimesheets("InvalidStatus"));
    }

    @Test
    public void testGetPendingWeeklyTimesheets() {
        when(weeklyTimeSheetRepository.getByStatus("Pending")).thenReturn(List.of(weeklyTimeSheet));

        List<WeeklyTimeSheet> result = weeklyTimeSheetService.getPendingWeeklyTimesheets("Pending");

        assertEquals(1, result.size());
        assertEquals(weeklyTimeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testExistsByEmpId() {
        when(weeklyTimeSheetRepository.existsByEmpId(1)).thenReturn(true);

        assertTrue(weeklyTimeSheetService.existsByEmpId(1));
    }

    @Test
    public void testSubmitWeeklyTimeSheet_EmployeeNotFound() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now()));
    }

    @Test
    public void testSubmitWeeklyTimeSheet_TimesheetsNotFound() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetRepository.getByEmpIdAndDateBetween(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(Collections.emptyList());

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now()));
        assertEquals("Timesheets from: " + LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) + " to " + LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)) + " do not exist", exception.getMessage());
    }
    @Test
    public void testSubmitWeeklyTimeSheet_Success() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetRepository.getByEmpIdAndDateBetween(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(List.of(timeSheet));
        when(weeklyTimeSheetRepository.save(any(WeeklyTimeSheet.class))).thenReturn(weeklyTimeSheet);

        WeeklyTimeSheet result = weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now());

        assertEquals(weeklyTimeSheet.getEmpId(), result.getEmpId());
        assertEquals(weeklyTimeSheet.getTotalHours(), result.getTotalHours());
    }

    @Test
    public void testOnlyUpdateTimesheet_TimesheetNotFound() {
        when(timeSheetService.findByEmpIdAndDate(anyInt(), any(LocalDate.class))).thenReturn(Optional.empty());

        UpdateTimesheetDto updateTimesheetDto = new UpdateTimesheetDto();
        updateTimesheetDto.setTopUpHours(2.00);
        updateTimesheetDto.setHoursWorked(8.00);
        updateTimesheetDto.setOvertimeHours(1.00);
        updateTimesheetDto.setClockIn(Time.valueOf("9:00:00"));
        updateTimesheetDto.setClockOut(Time.valueOf("17:00:00"));

        assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.onlyUpdateTimesheet(1, LocalDate.now(), updateTimesheetDto));
    }

    @Test
    public void testOnlyUpdateTimesheet_Success() {
        when(timeSheetService.findByEmpIdAndDate(anyInt(), any(LocalDate.class))).thenReturn(Optional.of(timeSheet));
        when(timeSheetRepository.save(any(TimeSheet.class))).thenReturn(timeSheet);

        UpdateTimesheetDto updateTimesheetDto = new UpdateTimesheetDto();
        updateTimesheetDto.setTopUpHours(2.00);
        updateTimesheetDto.setHoursWorked(8.00);
        updateTimesheetDto.setOvertimeHours(1.00);
        updateTimesheetDto.setClockIn(Time.valueOf("9:00:00"));
        updateTimesheetDto.setClockOut(Time.valueOf("17:00:00"));

        TimeSheet result = weeklyTimeSheetService.onlyUpdateTimesheet(1, LocalDate.now(), updateTimesheetDto);

        assertEquals(timeSheet.getEmpId(), result.getEmpId());
        assertEquals(timeSheet.getTotal_Hours(), result.getTotal_Hours());
    }

    @Test
    public void testUpdateTimesheet_TimesheetNotFound() {
        when(timeSheetService.findByEmpIdAndDate(anyInt(), any(LocalDate.class))).thenReturn(Optional.empty());

        UpdateTimesheetDto updateTimesheetDto = new UpdateTimesheetDto();
        updateTimesheetDto.setTopUpHours(2.00);
        updateTimesheetDto.setHoursWorked(8.00);
        updateTimesheetDto.setOvertimeHours(1.00);
        updateTimesheetDto.setClockIn(Time.valueOf("9:00:00"));
        updateTimesheetDto.setClockOut(Time.valueOf("17:00:00"));

        assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.updateTimesheet(1, LocalDate.now(), updateTimesheetDto));
    }
}