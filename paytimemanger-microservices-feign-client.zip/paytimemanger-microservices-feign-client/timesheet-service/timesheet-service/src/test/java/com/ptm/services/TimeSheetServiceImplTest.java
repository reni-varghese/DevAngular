package com.ptm.services;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.responses.SuccessCreation;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.InvalidInputException;
import com.ptm.models.TimeSheet;
import com.ptm.repositories.TimeSheetRepository;
import com.ptm.services.impl.TimeSheetServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.sql.Time;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TimeSheetServiceImplTest {

    @Mock
    private TimeSheetRepository timeSheetRepository;

    @InjectMocks
    private TimeSheetServiceImpl timeSheetService;

    private TimesheetDto timesheetDto;
    private TimeSheet timeSheet;

    @BeforeEach
    public void setUp() {
        timesheetDto = new TimesheetDto();
        timesheetDto.setEmpId(1);
        timesheetDto.setDate(LocalDate.now());
        timesheetDto.setClockIn(Time.valueOf("9:00:00"));
        timesheetDto.setClockOut(Time.valueOf("17:00:00"));
        timesheetDto.setTopUpHours(2.00);

        timeSheet = new TimeSheet();
        timeSheet.setEmpId(1);
        timeSheet.setDate(LocalDate.now());
        timeSheet.setClock_In(Time.valueOf("9:00:00"));
        timeSheet.setClock_Out(Time.valueOf("17:00:00"));
        timeSheet.setTopup_Hours(2.00);
    }

    @Test
    public void testExistsByEmpId() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);

        assertTrue(timeSheetService.existsByEmpId(1));
    }

    @Test
    public void testExistsByDate() {
        LocalDate date = LocalDate.now();
        when(timeSheetRepository.existsByDate(date)).thenReturn(true);

        assertTrue(timeSheetService.existsByDate(date));
    }

    @Test
    public void testExistsByDateAndEmpId() {
        LocalDate date = LocalDate.now();
        when(timeSheetRepository.existsByDateAndEmpId(date, 1)).thenReturn(timeSheet);

        assertEquals(timeSheet, timeSheetService.existsByDateAndEmpId(date, 1));
    }

    @Test
    public void testGetAll() {
        when(timeSheetRepository.findAll()).thenReturn(List.of(timeSheet));

        List<TimesheetDto> result = timeSheetService.getAll();

        assertEquals(1, result.size());
        assertEquals(timesheetDto.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testGetById_EmployeeNotFound() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> timeSheetService.getById(1));
    }

    @Test
    public void testGetById() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetRepository.getByEmpId(1)).thenReturn(List.of(timeSheet));

        List<TimesheetDto> result = timeSheetService.getById(1);

        assertEquals(1, result.size());
        assertEquals(timesheetDto.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testGetByEmpIdAndDate_InvalidInput() {
        LocalDate from = LocalDate.now();
        LocalDate to = from.minusDays(1);

        assertThrows(InvalidInputException.class, () -> timeSheetService.getByEmpIdAndDate(1, from, to));
    }

    @Test
    public void testGetByEmpIdAndDate_EmployeeNotFound() {
        LocalDate from = LocalDate.now();
        LocalDate to = from.plusDays(1);
        when(timeSheetRepository.getByEmpIdAndDateBetween(1, from, to)).thenReturn(Collections.emptyList());

        assertThrows(EmployeeNotFoundException.class, () -> timeSheetService.getByEmpIdAndDate(1, from, to));
    }

    @Test
    public void testGetByEmpIdAndDate() {
        LocalDate from = LocalDate.now();
        LocalDate to = from.plusDays(1);
        when(timeSheetRepository.getByEmpIdAndDateBetween(1, from, to)).thenReturn(List.of(timeSheet));

        List<TimesheetDto> result = timeSheetService.getByEmpIdAndDate(1, from, to);

        assertEquals(1, result.size());
        assertEquals(timesheetDto.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    public void testFindByEmpIdAndDate() {
        LocalDate date = LocalDate.now();
        when(timeSheetRepository.getByEmpIdAndDate(1, date)).thenReturn(Optional.of(timeSheet));

        Optional<TimeSheet> result = timeSheetService.findByEmpIdAndDate(1, date);

        assertTrue(result.isPresent());
        assertEquals(timeSheet, result.get());
    }

    @Test
    public void testAdd_InvalidEmpId() {
        timesheetDto.setEmpId(0);

        assertThrows(InvalidInputException.class, () -> timeSheetService.add(timesheetDto));
    }

    @Test
    public void testAdd_InvalidDate() {
        timesheetDto.setDate(null);

        assertThrows(InvalidInputException.class, () -> timeSheetService.add(timesheetDto));
    }

    @Test
    public void testAdd_InvalidClockIn() {
        timesheetDto.setClockIn(null);

        assertThrows(InvalidInputException.class, () -> timeSheetService.add(timesheetDto));
    }

    @Test
    public void testAdd_InvalidClockOut() {
        timesheetDto.setClockOut(null);

        assertThrows(InvalidInputException.class, () -> timeSheetService.add(timesheetDto));
    }

    @Test
    public void testAdd_TimesheetAlreadyExists() {
        when(timeSheetRepository.existsByDateAndEmpId(timesheetDto.getDate(), timesheetDto.getEmpId())).thenReturn(timeSheet);

        assertThrows(InvalidInputException.class, () -> timeSheetService.add(timesheetDto));
    }

    @Test
    public void testAdd_Success() {
        when(timeSheetRepository.existsByDateAndEmpId(timesheetDto.getDate(), timesheetDto.getEmpId())).thenReturn(null);
        when(timeSheetRepository.save(any(TimeSheet.class))).thenReturn(timeSheet);

        SuccessCreation result = timeSheetService.add(timesheetDto);

        assertEquals("Timesheet added successfully", result.getMessage());
        assertEquals(HttpStatus.CREATED.value(), result.getStatus());
    }
}