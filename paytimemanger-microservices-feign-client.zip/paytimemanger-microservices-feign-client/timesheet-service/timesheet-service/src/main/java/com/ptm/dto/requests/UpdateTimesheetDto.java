package com.ptm.dto.requests;

import java.sql.Time;

public class UpdateTimesheetDto {
    private Double hoursWorked;
    private Double overtimeHours;
    private Double topUpHours;
    private Time clockIn;
    private Time clockOut;

    public Time getClockIn() {
        return clockIn;
    }

    public void setClockIn(Time clockIn) {
        this.clockIn = clockIn;
    }

    public Time getClockOut() {
        return clockOut;
    }

    public void setClockOut(Time clockOut) {
        this.clockOut = clockOut;
    }

    public Double getTopUpHours() {
        return topUpHours;
    }

    public void setTopUpHours(Double topUpHours) {
        this.topUpHours = topUpHours;
    }



    public Double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(Double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public Double getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(Double overtimeHours) {
        this.overtimeHours = overtimeHours;
    }


// Getters and Setters

}
