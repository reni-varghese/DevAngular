package com.ptm.services;

import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;

import java.time.LocalDate;
import java.util.List;

public interface WeeklyTimeSheetService {
    List<WeeklyTimeSheet> getAll();
    List<TimeSheet> getTimeSheetsFromMondayToCurrent(int empId, LocalDate curr);
    boolean existsByEmpId(int empId);
    List<WeeklyTimeSheet> getPendingWeeklyTimesheets(String status);
    WeeklyTimeSheet submitWeeklyTimeSheet(int empId, LocalDate currentDate);
    //    WeeklyTimesheet createWeeklyTimesheet(WeeklyTimesheetDto weeklyTimesheetDto);
    TimeSheet onlyUpdateTimesheet(int id, LocalDate date, UpdateTimesheetDto updateTimesheetDTO);
    TimeSheet updateTimesheet(int id, LocalDate date, UpdateTimesheetDto updateTimesheetDto);
    List<WeeklyTimeSheet> findByEmpIdAndStatus(int empId, String status);
}
