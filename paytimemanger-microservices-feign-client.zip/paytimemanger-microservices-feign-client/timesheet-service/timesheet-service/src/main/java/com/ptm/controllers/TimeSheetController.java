package com.ptm.controllers;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.responses.SuccessCreation;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.services.TimeSheetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/timesheet-summary")
@Slf4j
public class TimeSheetController {
    private final TimeSheetService timeSheetServiceImplementation;

    public TimeSheetController(TimeSheetService timeSheetServiceImplementation) {
        this.timeSheetServiceImplementation = timeSheetServiceImplementation;
    }

    @GetMapping
    public List<TimesheetDto> getAllDetails() {
        log.info("Fetching all timesheet details.");
        return timeSheetServiceImplementation.getAll();
    }

    @GetMapping("/id/{empId}")
    public ResponseEntity<List<TimesheetDto>> getDataById(@PathVariable int empId) {
        log.info("Fetching timesheet data for employee ID: {}", empId);
        if (timeSheetServiceImplementation.existsByEmpId(empId)) {
            List<TimesheetDto> timesheetData = timeSheetServiceImplementation.getById(empId);
            log.info("Timesheet data for employee ID: {} retrieved successfully.", empId);
            return ResponseEntity.ok(timesheetData);
        }
        log.error("Employee with ID: {} does not exist.", empId);
        throw new EmployeeNotFoundException("Employee with Id " + empId + " does not exist");
    }

    @GetMapping("/id/date/{empId}")
    public List<TimesheetDto> getDataByIdAndDate(@PathVariable int empId, @RequestParam("from") LocalDate from, @RequestParam("To") LocalDate to) {
        log.info("Fetching timesheet data for employee ID: {} from {} to {}", empId, from, to);
        List<TimesheetDto> timesheetData = timeSheetServiceImplementation.getByEmpIdAndDate(empId, from, to);
        log.info("Timesheet data for employee ID: {} from {} to {} retrieved successfully.", empId, from, to);
        return timesheetData;
    }

    @PostMapping
    public SuccessCreation addTimesheet(@RequestBody TimesheetDto timesheetDto) {
        log.info("Adding new timesheet: {}", timesheetDto);
        SuccessCreation successCreation = timeSheetServiceImplementation.add(timesheetDto);
        log.info("Timesheet added successfully: {}", timesheetDto);
        return successCreation;
    }
}
