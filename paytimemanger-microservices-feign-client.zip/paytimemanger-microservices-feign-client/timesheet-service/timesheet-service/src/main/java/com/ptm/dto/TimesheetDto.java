package com.ptm.dto;

import java.sql.Time;
import java.time.LocalDate;

public class TimesheetDto {
    private int empId;
    private LocalDate date;

    private Time clockIn;
    private Time clockOut;
    private Double topUpHours;


    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Time getClockIn() {
        return clockIn;
    }

    public void setClockIn(Time clockIn) {
        this.clockIn = clockIn;
    }

    public Time getClockOut() {
        return clockOut;
    }

    public void setClockOut(Time clockOut) {
        this.clockOut = clockOut;
    }

    public Double getTopUpHours() {
        return topUpHours;
    }

    public void setTopUpHours(Double topUpHours) {
        this.topUpHours = topUpHours;
    }
}
