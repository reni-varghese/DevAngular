package com.ptm.services;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.responses.SuccessCreation;
import com.ptm.models.TimeSheet;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TimeSheetService {
    List<TimesheetDto> getAll();

    List<TimesheetDto> getById(int empId);

    List<TimesheetDto> getByEmpIdAndDate(int empId, LocalDate from, LocalDate to);

    Optional<TimeSheet> findByEmpIdAndDate(int empId, LocalDate date);
    SuccessCreation add(TimesheetDto timesheetDto);
    boolean existsByDate(LocalDate date);
    boolean existsByEmpId(int empId);

    TimeSheet existsByDateAndEmpId(LocalDate date, int empId);
}
