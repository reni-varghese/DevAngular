package com.ptm.services;

import com.ptm.client.AuthClient;
import com.ptm.dto.ValidTokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TokenService {
    private final AuthClient authClient;

    public boolean isTokenValid(String token)
    {
        ResponseEntity<ValidTokenResponse> response = authClient.validateToken(token);
        return response.getBody() != null && response.getBody().isValid();
    }
}
