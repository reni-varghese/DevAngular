package com.ptm.client;

import com.ptm.dto.WeeklyTimeSheetDTO;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.List;
@FeignClient(name = "timesheet-service")
public interface WeeklyTimeSheetClient {
    @GetMapping("/weekly-summary/salary-timesheets")
    @CircuitBreaker(name = "timesheetService", fallbackMethod = "fallbackFindByEmpIdAndStatus")
    List<WeeklyTimeSheetDTO> findByEmpIdAndStatus(@RequestParam int empId, @RequestParam String status);

    default List<WeeklyTimeSheetDTO> fallbackFindByEmpIdAndStatus(int empId, String status, Throwable throwable) {
        // Fallback logic
        return Collections.emptyList();
    }
}