package com.ptm.services;

import com.ptm.dto.PayRateDTO;
import com.ptm.dto.responses.CustomResponse;

import java.util.List;
import java.util.Map;

public interface PayRatesService {
    CustomResponse addPayRate(PayRateDTO payRateDTO);
    PayRateDTO getPayRateById(int id);
    List<PayRateDTO> getAllPayRate();
    PayRateDTO partialUpdatePayRate(int id, Map<String, Object> updates);
}
