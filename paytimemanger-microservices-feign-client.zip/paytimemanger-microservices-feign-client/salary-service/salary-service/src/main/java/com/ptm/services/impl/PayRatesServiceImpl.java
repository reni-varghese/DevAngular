package com.ptm.services.impl;

import com.ptm.dto.PayRateDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.exceptions.EmployeeAlreadyExistsException;
import com.ptm.exceptions.PayRateNotFoundException;
import com.ptm.models.PayRate;
import com.ptm.repositories.PayRateRepository;
import com.ptm.services.PayRatesService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@Service
@Slf4j
public class PayRatesServiceImpl implements PayRatesService {

    private final PayRateRepository payRatesRepository;

    @Override
    public CustomResponse addPayRate(PayRateDTO payRateDTO) {
//        log.info("Adding new pay rate with ID: {}", payRateDTO.getPay_rateid());
        if (payRatesRepository.existsById(payRateDTO.getPay_rateid())) {
//            log.error("Pay rate with ID: {} already exists", payRateDTO.getPay_rateid());
            throw new EmployeeAlreadyExistsException("PayRate with ID " + payRateDTO.getPay_rateid() + " already exists");
        }
        PayRate payRate = convertToEntity(payRateDTO);
        PayRate savedPayRate = payRatesRepository.save(payRate);

        CustomResponse response = new CustomResponse();
        response.setTimestamp(LocalDateTime.now());
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("PayRate with ID " + savedPayRate.getPayRateId() + " is added successfully");

        log.info("Pay rate with ID: {} added successfully", savedPayRate.getPayRateId());

        return response;
    }

    @Override
    public PayRateDTO getPayRateById(int id) {
        log.info("Fetching pay rate with ID: {}", id);
        PayRate payRate = payRatesRepository.findById(id)
                .orElseThrow(() -> new PayRateNotFoundException("PayRate with id " + id + " not found"));
        return convertToDTO(payRate);
    }

    @Override
    public List<PayRateDTO> getAllPayRate() {
        log.info("Fetching all pay rates");
        return payRatesRepository.findAll().stream()
                .map(this::convertToDTO)
                .toList();
    }

    @Override
    public PayRateDTO partialUpdatePayRate(int id, Map<String, Object> updates) {
        log.info("Partially updating pay rate with ID: {} with updates: {}", id, updates);
        PayRate existingPayRate = payRatesRepository.findById(id)
                .orElseThrow(() -> new PayRateNotFoundException("PayRate with id " + id + " not found"));

        updates.forEach((key, value) -> {
            switch (key) {
                case "basicPay":
                    existingPayRate.setBasicPay((Double) value);
                    break;
                case "overtimePay":
                    existingPayRate.setOvertimePay((Double) value);
                    break;
                case "pf":
                    existingPayRate.setPf((Double) value);
                    break;
                case "hra":
                    existingPayRate.setHra((Double) value);
                    break;
                case "mobileReimbursement":
                    existingPayRate.setMobileReimbursement((Double) value);
                    break;
                case "foodReimbursement":
                    existingPayRate.setFoodReimbursement((Double) value);
                    break;
                case "specialAllowance":
                    existingPayRate.setSpecialAllowance((Double) value);
                    break;
                case "cashAllowance":
                    existingPayRate.setCashAllowance((Double) value);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid field: " + key);
            }
        });

        log.info("Pay rate with ID: {} updated successfully", id);
        return convertToDTO(payRatesRepository.save(existingPayRate));
    }

    private PayRate convertToEntity(PayRateDTO payRateDTO) {
        PayRate payRate = new PayRate();
        payRate.setEmpRole(payRateDTO.getEmpRole());
        payRate.setBasicPay(payRateDTO.getBasicPay());
        payRate.setOvertimePay(payRateDTO.getOvertimePay());
        payRate.setPf(payRateDTO.getPf());
        payRate.setHra(payRateDTO.getHra());
        payRate.setMobileReimbursement(payRateDTO.getMobileReimbursement());
        payRate.setFoodReimbursement(payRateDTO.getFoodReimbursement());
        payRate.setSpecialAllowance(payRateDTO.getSpecialAllowance());
        payRate.setCashAllowance(payRateDTO.getCashAllowance());
        return payRate;
    }

    private PayRateDTO convertToDTO(PayRate payRate) {
        PayRateDTO payRateDTO = new PayRateDTO();
        payRateDTO.setPay_rateid(payRate.getPayRateId());
        payRateDTO.setEmpRole(payRate.getEmpRole());
        payRateDTO.setBasicPay(payRate.getBasicPay());
        payRateDTO.setOvertimePay(payRate.getOvertimePay());
        payRateDTO.setPf(payRate.getPf());
        payRateDTO.setHra(payRate.getHra());
        payRateDTO.setMobileReimbursement(payRate.getMobileReimbursement());
        payRateDTO.setFoodReimbursement(payRate.getFoodReimbursement());
        payRateDTO.setSpecialAllowance(payRate.getSpecialAllowance());
        payRateDTO.setCashAllowance(payRate.getCashAllowance());
        return payRateDTO;
    }
}
