package com.ptm.controllers;

import com.ptm.dto.requests.SalaryCalculationRequestDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.dto.responses.SalaryDTO;
import com.ptm.models.Salary;
import com.ptm.services.ISalaryCalculationService;
import com.ptm.services.SalaryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/salary")
@Slf4j
public class SalaryController {

    private final SalaryService salaryService;
    private final ISalaryCalculationService salaryCalculationService;

    // admin-dashboard
    @GetMapping("/yearly-sums")
    public ResponseEntity<Map<Integer, Double>> getYearlySumOfSalaries() {
        log.info("Fetching yearly sum of salaries.");
        Map<Integer, Double> yearlySums = salaryService.getYearlySumOfSalaries();
        log.info("Yearly sums retrieved: {}", yearlySums);
        return ResponseEntity.ok(yearlySums);
    }

    // employee_earnings-overview
    @GetMapping("/employee/{empID}")
    public ResponseEntity<List<Salary>> getSalariesByEmpId(@PathVariable int empID) {
        log.info("Fetching salaries for employee ID: {}", empID);
        List<Salary> salaries = salaryService.getSalariesByEmpID(empID);
        log.info("Salaries for employee ID: {} retrieved: {}", empID, salaries);
        return ResponseEntity.ok(salaries);
    }

    // payroll
    @GetMapping("/payroll-details")
    public ResponseEntity<List<SalaryDTO>> getAllSalaryEmployeeDetails() {
        log.info("Fetching all salary employee details.");
        List<SalaryDTO> salaryEmployeeDetails = salaryService.getAllSalaryEmployeeDetails();
        log.info("All salary employee details retrieved: {}", salaryEmployeeDetails);
        return ResponseEntity.ok(salaryEmployeeDetails);
    }

    //calculate salary and store in db
    @PostMapping("/calculate")
    public ResponseEntity<CustomResponse> calculateSalary(@RequestBody SalaryCalculationRequestDTO request) {
        log.info("Calculating salary for month-year: {}", request.getMonthYear());
        salaryCalculationService.calculateAndStoreSalary(request.getMonthYear());
        CustomResponse response = new CustomResponse(
                HttpStatus.OK.value(),
                "Salaries calculated and stored successfully",
                LocalDateTime.now()
        );
        log.info("Salaries calculated and stored successfully for month-year: {}", request.getMonthYear());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
