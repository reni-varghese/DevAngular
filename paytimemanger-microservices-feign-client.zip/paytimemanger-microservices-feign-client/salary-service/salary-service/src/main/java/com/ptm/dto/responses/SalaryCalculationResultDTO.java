package com.ptm.dto.responses;

import lombok.Data;

import java.time.LocalDate;
import java.time.YearMonth;


@Data
public class SalaryCalculationResultDTO {
    private int empId;
    private YearMonth monthYear;
    private double basicPay;
    private double claims;
    private double deductions;
    private double netPay;
    private LocalDate payrollProcessedDate;
}
