package com.ptm.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class WeeklyTimeSheetDTO {
    private int weeklyTimesheetId;
    private int empId;
    private LocalDate weekStart;
    private LocalDate weekEnd;
    private double totalHours;
    private double overtimeHours;
    private String status;
    private String feedback;
    private boolean isResubmitted;
    private LocalDate actionDate;
}