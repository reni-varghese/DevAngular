package com.ptm.repositories;

import com.ptm.models.Salary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SalaryRepository extends JpaRepository<Salary, Integer> {
    @Query("SELECT YEAR(s.monthYear) as year, SUM(s.netPay) as yearlySum FROM Salary s GROUP BY YEAR(s.monthYear)")
    List<Object[]> findYearlySumOfSalaries();

    //employee_earnings-overview
    List<Salary> findSalaryByEmpId(int empID);

//

}
