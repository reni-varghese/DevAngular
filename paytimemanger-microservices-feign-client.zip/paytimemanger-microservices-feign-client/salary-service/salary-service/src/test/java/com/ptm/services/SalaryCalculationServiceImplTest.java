package com.ptm.services;

import com.ptm.exceptions.PayRateNotFoundException;
import com.ptm.models.*;
import com.ptm.repositories.*;
import com.ptm.services.impl.SalaryCalculationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SalaryCalculationServiceImplTest {

    @Mock
    private WeeklyTimeSheetRepository weeklyTimeSheetRepository;

    @Mock
    private CashClaimsAndAllowanceRepository cashClaimsAndAllowanceRepository;

    @Mock
    private PayRateRepository payRateRepository;

    @Mock
    private SalaryRepository salaryRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private SalaryCalculationServiceImpl salaryCalculationService;

    private Employee employee;
    private WeeklyTimeSheet weeklyTimeSheet;
    private CashClaimsAndAllowance cashClaimsAndAllowance;
    private PayRate payRate;
    private YearMonth monthYear;

    @BeforeEach
    public void setUp() {
        employee = new Employee();
        employee.setEmpId(1);
        employee.setEmpRole("Developer");

        weeklyTimeSheet = new WeeklyTimeSheet();
        weeklyTimeSheet.setEmpId(1);
        weeklyTimeSheet.setWeekStart(LocalDate.of(2023, 1, 1));
        weeklyTimeSheet.setTotalHours(40);
        weeklyTimeSheet.setStatus("Approved");

        cashClaimsAndAllowance = new CashClaimsAndAllowance();
        cashClaimsAndAllowance.setEmpId(1);
        cashClaimsAndAllowance.setDateOfClaim(LocalDate.of(2023, 1, 15));
        cashClaimsAndAllowance.setAmount(1000.0);

        payRate = new PayRate();
        payRate.setEmpRole("Developer");
        payRate.setBasicPay(100.0);
        payRate.setPf(10.0);

        monthYear = YearMonth.of(2023, 1);
    }

    @Test
    public void testCalculateAndStoreSalary_Success() {
        when(employeeRepository.findByEmpRoleNot("Admin")).thenReturn(List.of(employee));
        when(weeklyTimeSheetRepository.findByEmpIdAndStatus(1, "Approved")).thenReturn(List.of(weeklyTimeSheet));
        when(cashClaimsAndAllowanceRepository.findByEmpId(1)).thenReturn(List.of(cashClaimsAndAllowance));
        when(payRateRepository.findByEmpRole("Developer")).thenReturn(Optional.of(payRate));

        salaryCalculationService.calculateAndStoreSalary(monthYear);

        verify(salaryRepository, times(1)).save(any(Salary.class));
    }

    @Test
    public void testCalculateAndStoreSalary_NoApprovedTimesheets() {
        when(employeeRepository.findByEmpRoleNot("Admin")).thenReturn(List.of(employee));
        when(weeklyTimeSheetRepository.findByEmpIdAndStatus(1, "Approved")).thenReturn(Collections.emptyList());

        salaryCalculationService.calculateAndStoreSalary(monthYear);

        verify(salaryRepository, never()).save(any(Salary.class));
    }

    @Test
    public void testCalculateAndStoreSalary_PayRateNotFound() {
        when(employeeRepository.findByEmpRoleNot("Admin")).thenReturn(List.of(employee));
        when(weeklyTimeSheetRepository.findByEmpIdAndStatus(1, "Approved")).thenReturn(List.of(weeklyTimeSheet));
        when(cashClaimsAndAllowanceRepository.findByEmpId(1)).thenReturn(List.of(cashClaimsAndAllowance));
        when(payRateRepository.findByEmpRole("Developer")).thenReturn(Optional.empty());

        assertThrows(PayRateNotFoundException.class, () -> salaryCalculationService.calculateAndStoreSalary(monthYear));
    }

    @Test
    public void testCalculateAndStoreSalary_NoClaims() {
        when(employeeRepository.findByEmpRoleNot("Admin")).thenReturn(List.of(employee));
        when(weeklyTimeSheetRepository.findByEmpIdAndStatus(1, "Approved")).thenReturn(List.of(weeklyTimeSheet));
        when(cashClaimsAndAllowanceRepository.findByEmpId(1)).thenReturn(Collections.emptyList());
        when(payRateRepository.findByEmpRole("Developer")).thenReturn(Optional.of(payRate));

        salaryCalculationService.calculateAndStoreSalary(monthYear);

        verify(salaryRepository, times(1)).save(any(Salary.class));
    }
}