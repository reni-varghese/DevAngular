package com.ptm.services;

import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.models.OTP;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.repositories.OTPRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;

@Service
@Slf4j
@RequiredArgsConstructor
public class OTPServiceImpl implements OTPService {
    private final OTPRepository otpRepository;
    private final EmployeeRepository employeeRepository;
    //private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;
    Random random = new Random();



    @Override
    public String generateOtp(Integer empId) {
        log.info("Generating OTP for employee ID: {}", empId);
        String otp = String.format("%06d", this.random.nextInt(1000000));
        LocalDateTime now = LocalDateTime.now();

        OTP otpEntity = new OTP();
        otpEntity.setEmpId(empId);
        otpEntity.setOtp(otp);
        otpEntity.setDateCreated(now);

        otpRepository.save(otpEntity);

        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        try {
            //emailService.sendOtpEmail(employee.getEmpEmail(), otp);
            log.info("OTP sent successfully to email: {}", employee.getEmpEmail());
        } catch (Exception e) {
            log.error("Error sending OTP email to: {}", employee.getEmpEmail(), e);
        }

        return otp;
    }

    @Override
    public boolean validateOtp(Integer empId, String otp, String newPassword) {
        log.info("Validating OTP for employee ID: {}", empId);
        LocalDateTime validFrom = LocalDateTime.now().minus(5, ChronoUnit.MINUTES);
        List<OTP> validOtps = otpRepository.findValidOtpsByEmpId(empId, validFrom);

        for (OTP otpEntity : validOtps) {
            if (otpEntity.getOtp().equals(otp)) {
                otpRepository.deleteById(otpEntity.getOtpId());
                updatePassword(empId, passwordEncoder.encode(newPassword));
                log.info("OTP validated successfully for employee ID: {}", empId);
                return true;
            }
        }
        log.warn("Invalid OTP for employee ID: {}", empId);
        return false;
    }

    @Override
    public void updatePassword(Integer empId, String newPassword) {
        log.info("Updating password for employee ID: {}", empId);
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        employee.setPassword(newPassword);
        employeeRepository.save(employee);
        log.info("Password updated successfully for employee ID: {}", empId);
    }
}
