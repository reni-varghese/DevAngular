package com.ptm.dtos.responses;

import java.sql.Timestamp;

public class TokenResponse {
    private String message;
    private int statusCode;
    private Timestamp timestamp;
    private String token;
    private String type = "Bearer";


    public TokenResponse() {
    }

    public TokenResponse(String message, int statusCode, Timestamp timestamp, String token, String type) {
        this.message = message;
        this.statusCode = statusCode;
        this.timestamp = timestamp;
        this.token = token;
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
