package com.ptm.controllers;

import com.ptm.dtos.*;
import com.ptm.dtos.responses.AuthResponseDto;
import com.ptm.dtos.responses.TokenResponse;
import com.ptm.dtos.responses.ValidTokenResponse;
import com.ptm.exceptions.TokenNotFoundException;
import com.ptm.security.JwtProvider;
import com.ptm.services.AuthService;
import com.ptm.services.BlackListTokenService;
import com.ptm.services.BlackListTokenServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthService authServiceImpl;
    private final JwtProvider jwtProvider;
    private final BlackListTokenService blackListTokenServiceImpl;

    @PostMapping("/login")
    public ResponseEntity<TokenResponse> login(@RequestBody LoginDto loginDto) {
        log.info("Login request received for user: {}", loginDto.getEmail());

        var result = authServiceImpl.login(loginDto);

        TokenResponse tokenResponse = new TokenResponse();
        tokenResponse.setMessage("Employee Authenticated Successfully");
        tokenResponse.setStatusCode(HttpStatus.OK.value());
        tokenResponse.setTimestamp(new Timestamp(System.currentTimeMillis()));
        tokenResponse.setToken(result);

        log.info("User {} authenticated successfully.", loginDto.getEmail());

        return new ResponseEntity<>(tokenResponse, HttpStatus.OK);
    }

    @PutMapping("/reset-password")
    public ResponseEntity<AuthResponseDto> passwordReset(@RequestBody ResetPassDto resetPassDto, @RequestHeader("Authorization") String token) {
        log.info("Password reset request received.");

        String email;
        AuthResponseDto responseDto = new AuthResponseDto();
        responseDto.setTimestamp(new Timestamp(System.currentTimeMillis()));

        if (StringUtils.hasText(token) && token.startsWith("Bearer ")) {
            email = jwtProvider.getEmailFromToken(token.substring(7));
            log.info("Token validated. Email extracted: {}", email);
        } else {
            responseDto.setMessage("Token Not Found or Incorrect");
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.warn("Token not found or incorrect.");
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        }

        try {
            String response = authServiceImpl.resetPassword(resetPassDto, email);
            responseDto.setMessage(response);
            responseDto.setStatusCode(HttpStatus.OK.value());
            log.info("Password reset successful for email: {}", email);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (TokenNotFoundException e) {
            responseDto.setMessage("Token Not Found or Incorrect");
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.error("Token not found or incorrect.", e);
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        } catch (Exception e) {
            responseDto.setMessage("Internal Server Error");
            responseDto.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("Internal server error occurred during password reset.", e);
            return new ResponseEntity<>(responseDto, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<AuthResponseDto> logout(@RequestHeader("Authorization") String token) {
        log.info("Logout request received.");

        AuthResponseDto responseDto = new AuthResponseDto();
        responseDto.setTimestamp(new Timestamp(System.currentTimeMillis()));

        if (StringUtils.hasText(token) && token.startsWith("Bearer ")) {
            String jwtToken = token.substring(7);
            LocalDateTime expirationTime = jwtProvider.extractExpiration(jwtToken);

            BlackListTokenDto tokenBlackListDto = new BlackListTokenDto(jwtToken, expirationTime);
            blackListTokenServiceImpl.addBlackListedToken(tokenBlackListDto);

            responseDto.setMessage("Logout Successful");
            responseDto.setStatusCode(HttpStatus.OK.value());
            log.info("Logout successful for token: {}", jwtToken);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } else {
            responseDto.setMessage("Token Not Found or Incorrect");
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.warn("Token not found or incorrect.");
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        }


    }
    @GetMapping("/validate/{token}")
    public ResponseEntity<ValidTokenResponse> validateToken(@PathVariable String token)
    {
        boolean valid = jwtProvider.validateToken(token) && !blackListTokenServiceImpl.isTokenBlacklisted(token);
        return ResponseEntity.ok(new ValidTokenResponse(valid));
    }

}
