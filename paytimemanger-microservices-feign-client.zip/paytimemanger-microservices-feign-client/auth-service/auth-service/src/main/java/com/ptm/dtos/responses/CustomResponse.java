package com.ptm.dtos.responses;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class CustomResponse {
    private int statusCode;
    private String message;
    private LocalDateTime timestamp;


    public CustomResponse() {
    }

    public CustomResponse(int statusCode, String message, LocalDateTime timestamp) {
        this.statusCode = statusCode;
        this.message = message;
        this.timestamp = timestamp;
    }
}