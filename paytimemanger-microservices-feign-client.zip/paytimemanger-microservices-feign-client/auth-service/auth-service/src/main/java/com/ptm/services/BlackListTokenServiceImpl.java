package com.ptm.services;

import com.ptm.dtos.BlackListTokenDto;
import com.ptm.models.BlackListedToken;
import com.ptm.repositories.BlackListTokenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BlackListTokenServiceImpl implements BlackListTokenService {

    private final BlackListTokenRepository blackListTokenRepository;

    public BlackListTokenServiceImpl(BlackListTokenRepository blackListTokenRepository) {
        this.blackListTokenRepository = blackListTokenRepository;
    }

    @Override
    public void addBlackListedToken(BlackListTokenDto blackListTokenDto) {
        if(blackListTokenDto==null)
        {
            throw  new IllegalArgumentException("BlackListTokenDto cannot be null");
        }
        log.info("Adding token to blacklist: {}", blackListTokenDto.getToken());
        BlackListedToken blackListedToken = new BlackListedToken();
        blackListedToken.setToken(blackListTokenDto.getToken());
        blackListedToken.setExpirationTime(blackListTokenDto.getExpirationTime());

        blackListTokenRepository.save(blackListedToken);
        log.info("Token added to blacklist: {}", blackListTokenDto.getToken());
    }

    @Override
    public boolean isTokenBlacklisted(String token) {
        log.info("Checking if token is blacklisted: {}", token);
        boolean isBlacklisted = blackListTokenRepository.existsByToken(token);
        log.info("Token {} is blacklisted: {}", token, isBlacklisted);
        return isBlacklisted;
    }
}
