package com.ptm.dtos;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ResetPassDto {
    private String email;
    private String oldPassword;
    private String newPassword;

}
