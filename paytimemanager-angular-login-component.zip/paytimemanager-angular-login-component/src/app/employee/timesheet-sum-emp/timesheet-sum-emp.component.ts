import { Component } from '@angular/core';

@Component({
  selector: 'app-timesheet-sum-emp',
  standalone: false,
  templateUrl: './timesheet-sum-emp.component.html',
  styleUrl: './timesheet-sum-emp.component.css'
})
export class TimesheetSumEmpComponent {

}
