import { NgModule, Query } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { AddTimesheetComponent } from './add-timesheet/add-timesheet.component';
import { TimesheetSumEmpComponent } from './timesheet-sum-emp/timesheet-sum-emp.component';
import { AddCashClaimsComponent } from './add-cash-claims/add-cash-claims.component';
import { SalaryOverviewComponent } from './salary-overview/salary-overview.component';
import { AddQueryComponent } from './add-query/add-query.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';


   
    
  const employeeRoutes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Default route
    { path: 'dashboard', component: EmployeeDashboardComponent },
    { path: 'add-timesheet', component: AddTimesheetComponent },
    { path: 'cash-claims', component: AddCashClaimsComponent },
    { path: 'timesheet-summary', component: TimesheetSumEmpComponent },
    { path: 'add-query', component: AddQueryComponent },
    { path: 'salary-overview', component: SalaryOverviewComponent },
  ];

@NgModule({
  declarations: [
    EmployeeDashboardComponent,
    AddTimesheetComponent,
    TimesheetSumEmpComponent,
    AddCashClaimsComponent,
    SalaryOverviewComponent,
    AddQueryComponent,
    EmployeeComponent,
    
  ],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(employeeRoutes)
  
  ]
})
export class EmployeeModule { }
