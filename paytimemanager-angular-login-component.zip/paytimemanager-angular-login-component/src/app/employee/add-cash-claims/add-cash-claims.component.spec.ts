import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCashClaimsComponent } from './add-cash-claims.component';

describe('AddCashClaimsComponent', () => {
  let component: AddCashClaimsComponent;
  let fixture: ComponentFixture<AddCashClaimsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddCashClaimsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCashClaimsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
