import { Component } from '@angular/core';

@Component({
  selector: 'app-add-cash-claims',
  standalone: false,
  templateUrl: './add-cash-claims.component.html',
  styleUrl: './add-cash-claims.component.css'
})
export class AddCashClaimsComponent {

}
