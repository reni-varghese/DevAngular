import { Component } from '@angular/core';

@Component({
  selector: 'app-salary-overview',
  standalone: false,
  templateUrl: './salary-overview.component.html',
  styleUrl: './salary-overview.component.css'
})
export class SalaryOverviewComponent {

}
