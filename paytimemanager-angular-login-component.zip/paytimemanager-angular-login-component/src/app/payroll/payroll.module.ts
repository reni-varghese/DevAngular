import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayrollDashboardComponent } from './payroll-dashboard/payroll-dashboard.component';
import { TimesheetApproveComponent } from './timesheet-approve/timesheet-approve.component';
import { CashClaimsApproveComponent } from './cash-claims-approve/cash-claims-approve.component';
import { QueryReplyComponent } from './query-reply/query-reply.component';
import { PayrollComponent } from './payroll/payroll.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';

const payrollRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Default route
  { path: 'dashboard', component: PayrollDashboardComponent },
  { path: 'timesheet-approve', component: TimesheetApproveComponent },
  { path: 'cash-claims-approve', component: CashClaimsApproveComponent },
  { path: 'query-reply', component: QueryReplyComponent  }
 
];

@NgModule({
  declarations: [
    PayrollDashboardComponent,
    TimesheetApproveComponent,
    CashClaimsApproveComponent,
    QueryReplyComponent,
    PayrollComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(payrollRoutes),
    ReactiveFormsModule
  ]
})
export class PayrollModule { }
