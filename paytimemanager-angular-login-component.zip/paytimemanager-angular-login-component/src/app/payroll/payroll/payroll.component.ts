import { Component } from '@angular/core';

@Component({
  selector: 'app-payroll',
  standalone: false,
  templateUrl: './payroll.component.html',
  styleUrl: './payroll.component.css'
})
export class PayrollComponent {

}
