import { Component } from '@angular/core';

@Component({
  selector: 'app-cash-claims-approve',
  standalone: false,
  templateUrl: './cash-claims-approve.component.html',
  styleUrl: './cash-claims-approve.component.css'
})
export class CashClaimsApproveComponent {

}
