import { Component } from '@angular/core';

@Component({
  selector: 'app-query-reply',
  standalone: false,
  templateUrl: './query-reply.component.html',
  styleUrl: './query-reply.component.css'
})
export class QueryReplyComponent {

}
