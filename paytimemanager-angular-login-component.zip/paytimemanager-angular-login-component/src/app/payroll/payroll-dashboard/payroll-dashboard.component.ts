import { Component } from '@angular/core';

@Component({
  selector: 'app-payroll-dashboard',
  standalone: false,
  templateUrl: './payroll-dashboard.component.html',
  styleUrl: './payroll-dashboard.component.css'
})
export class PayrollDashboardComponent {

}
