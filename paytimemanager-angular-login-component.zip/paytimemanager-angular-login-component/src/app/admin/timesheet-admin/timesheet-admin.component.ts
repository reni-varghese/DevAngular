import { Component } from '@angular/core';

@Component({
  selector: 'app-timesheet-admin',
  standalone: false,
  templateUrl: './timesheet-admin.component.html',
  styleUrl: './timesheet-admin.component.css'
})
export class TimesheetAdminComponent {

}
