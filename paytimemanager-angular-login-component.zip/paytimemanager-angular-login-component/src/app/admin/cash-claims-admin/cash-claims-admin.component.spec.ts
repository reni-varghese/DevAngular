import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashClaimsAdminComponent } from './cash-claims-admin.component';

describe('CashClaimsAdminComponent', () => {
  let component: CashClaimsAdminComponent;
  let fixture: ComponentFixture<CashClaimsAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CashClaimsAdminComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CashClaimsAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
